import React, { useState, useMemo, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useLanguage } from '../../context/LanguageContext';
import { StorageService } from '../../services/storage';
import {
  Student,
  AttendanceRecord,
  Homework,
  HomeworkSubmission,
  FeeInvoice,
  FeeItem,
  FeePayment,
  RoutinePeriod,
  Exam,
  MarksEntry,
  Notice,
  OnlinePaymentRequest,
  MfsPaymentSettings,
  BlogPost,
} from '../../types';
import { calculateTotalGPA } from '../../utils/grading';
import {
  CalendarCheck2,
  BookOpen,
  CalendarDays,
  Award,
  Wallet,
  Bell,
  CheckCircle2,
  Clock,
  AlertTriangle,
  Upload,
  XCircle,
  Sparkles,
  Printer,
  ChevronRight,
  TrendingUp,
  FileText,
  User,
  ShieldCheck,
  Check,
  X,
  Camera,
  CreditCard,
  Smartphone,
  AlertCircle,
  Search,
  Lock,
  Calendar,
  BarChart3,
  GraduationCap,
  Building,
  Phone,
  KeyRound,
  Eye,
  Newspaper,
} from 'lucide-react';
import { SaturdayOffToggle } from '../common/SaturdayOffToggle';
import { AIService } from '../../services/aiService';
import { formatGroupName } from '../../utils/i18n';
import { compressImageToPassportSize } from '../../utils/storageHelper';
import { AccountCredentialsModal } from '../auth/AccountCredentialsModal';
import { SaaSApi, isSaaSBackendUnavailableError } from '../../services/saasApi';
import { isPublishedForStudents } from '../../utils/approvalWorkflow';
import {
  getPublishedExamRoutineGroupsForStudent,
  getPublishedSeatPlansForStudent,
} from '../../utils/studentExamPortal';
import {
  getLocalCalendarDateString,
  doesSubmissionBelongToStudent,
  getClassHomeworkForStudent,
  computeStudentHomeworkAccounting,
} from '../../utils/homeworkPortal';
import {
  findSubjectForMark,
  getMarksheetRowBreakdown,
} from '../../utils/marksheetBreakdown';
import { LauncherIconGrid, LauncherTileItem } from '../common/LauncherIconGrid';

interface StudentDedicatedDashboardProps {
  onNavigateTab?: (tab: string) => void;
}

export const StudentDedicatedDashboard: React.FC<StudentDedicatedDashboardProps> = ({ onNavigateTab }) => {
  const { currentUser, activeRole, saasSession } = useAuth();
  const { language, toBnNumber, formatTaka, formatDate } = useLanguage();
  const isGuardianView = activeRole === 'guardian';

  // Active module tab within Student/Guardian Dashboard (ID Card & QR Download hidden; Fees strictly Guardian-only; Blogs strictly Read-Only)
  const [activeSubTab, setActiveSubTab] = useState<'overview' | 'attendance' | 'homework' | 'routine' | 'exam_routine' | 'notices' | 'exams' | 'fees' | 'blogs'>('overview');
  const [showStudentCredsModal, setShowStudentCredsModal] = useState<boolean>(false);
  const [selectedChildId, setSelectedChildId] = useState<string>('');
  const [syncTick, setSyncTick] = useState<number>(0);
  const [blogSearchTerm, setBlogSearchTerm] = useState<string>('');
  const [blogCategoryFilter, setBlogCategoryFilter] = useState<string>('all');
  const [readingBlogPost, setReadingBlogPost] = useState<BlogPost | null>(null);

  useEffect(() => {
    if (!isGuardianView && activeSubTab === 'fees') {
      setActiveSubTab('overview');
    }
  }, [isGuardianView, activeSubTab]);

  // Listen for cloud sync snapshots, homework updates, and cross-tab storage updates
  useEffect(() => {
    const bumpSync = () => {
      setSyncTick((n) => n + 1);
    };
    window.addEventListener('school_cloud_data_synced', bumpSync);
    window.addEventListener('homework_submissions_updated', bumpSync);
    window.addEventListener('storage', bumpSync);
    return () => {
      window.removeEventListener('school_cloud_data_synced', bumpSync);
      window.removeEventListener('homework_submissions_updated', bumpSync);
      window.removeEventListener('storage', bumpSync);
    };
  }, []);

  // Reconcile homework submissions from server Admin SDK slice so student/guardian always sees latest submissions across devices
  useEffect(() => {
    if (!saasSession?.school?.schoolId) return;
    let cancelled = false;
    SaaSApi.listHomeworkSubmissions()
      .then((res) => {
        if (!cancelled && res?.success && Array.isArray(res.submissions)) {
          StorageService.replaceHomeworkSubmissionsLocal(res.submissions);
          setSyncTick((n) => n + 1);
        }
      })
      .catch(() => {});
    return () => {
      cancelled = true;
    };
  }, [saasSession?.school?.schoolId]);

  // Load all system data for student's class context (memoized on syncTick for referential stability)
  const students = useMemo(() => StorageService.getStudents(), [syncTick]);
  const allAttendance = useMemo(() => StorageService.getAttendance(), [syncTick]);
  const allHomework = useMemo(() => StorageService.getHomework(), [syncTick]);
  const allSubmissions = useMemo(() => StorageService.getHomeworkSubmissions(), [syncTick]);
  const allInvoices = useMemo(() => StorageService.getInvoices(), [syncTick]);
  const allPayments = useMemo(() => StorageService.getPayments(), [syncTick]);
  const allRoutines = useMemo(() => StorageService.getRoutines(), [syncTick]);
  const allExams = useMemo(() => StorageService.getExams(), [syncTick]);
  const allExamRoutines = useMemo(() => StorageService.getExamRoutines(), [syncTick]);
  const allSeatPlans = useMemo(() => StorageService.getExamSeatPlans(), [syncTick]);
  const allMarks = useMemo(() => StorageService.getMarks(), [syncTick]);
  const allSubjects = useMemo(() => StorageService.getSubjects(), [syncTick]);
  const allNotices = useMemo(() => StorageService.getNotices(), [syncTick]);
  const publishedBlogs = useMemo(() => StorageService.getPublishedBlogPosts(), [syncTick]);
  const school = useMemo(() => StorageService.getSchoolProfile(), [syncTick]);

  const blogCategories: { en: BlogPost['category']; bn: string }[] = [
    { en: 'Academic', bn: 'একাডেমিক' },
    { en: 'Science & Tech', bn: 'বিজ্ঞান ও প্রযুক্তি' },
    { en: 'Co-Curricular', bn: 'সহশিক্ষা ও বিতর্ক' },
    { en: 'Events', bn: 'স্কুল অনুষ্ঠান ও উৎসব' },
    { en: 'Sports', bn: 'খেলাধুলা ও শরীরচর্চা' },
    { en: 'Moral & Values', bn: 'নৈতিকতা ও চরিত্র গঠন' },
  ];

  const filteredBlogs = useMemo(() => {
    return publishedBlogs.filter((p) => {
      if (blogCategoryFilter !== 'all' && p.category !== blogCategoryFilter) return false;
      if (blogSearchTerm.trim() !== '') {
        const q = blogSearchTerm.toLowerCase();
        const matchBn =
          (p.titleBn || '').toLowerCase().includes(q) ||
          (p.content || '').toLowerCase().includes(q) ||
          (p.excerpt || '').toLowerCase().includes(q);
        const matchEn = (p.titleEn || '').toLowerCase().includes(q);
        return matchBn || matchEn;
      }
      return true;
    });
  }, [publishedBlogs, blogCategoryFilter, blogSearchTerm]);

  // STRICT DATA ISOLATION: Resolve authenticated student(s) for Student or Guardian login
  const matchedChildren: Student[] = useMemo(() => {
    const currentUsername = (currentUser.username || '').trim().toLowerCase();
    const currentName = (currentUser.name || '').trim().toLowerCase();
    const currentEmail = (currentUser.email || '').trim().toLowerCase();
    const normalizePhone = (p?: string) => (p || '').replace(/\D/g, '').slice(-10);
    const userPhoneNorm = normalizePhone(currentUser.phone);
    const isValidUserPhone = userPhoneNorm.length >= 10 && userPhoneNorm !== '1700000000';

    const list: Student[] = [];
    const pushUnique = (s?: Student | null) => {
      if (s && !list.some((x) => x.id === s.id)) {
        list.push(s);
      }
    };

    if (currentUser.linkedStudentId) {
      pushUnique(
        students.find(
          (s) => s && (s.id === currentUser.linkedStudentId || s.studentId === currentUser.linkedStudentId)
        )
      );
    }

    if (currentUser.authUid) {
      students.filter((s) => s && s.authUid && s.authUid === currentUser.authUid).forEach(pushUnique);
    }

    if (currentEmail) {
      students
        .filter((s) => s && s.email && s.email.trim().toLowerCase() === currentEmail)
        .forEach(pushUnique);
    }

    if (currentUsername) {
      students
        .filter(
          (s) =>
            s &&
            ((s.studentId && s.studentId.trim().toLowerCase() === currentUsername) ||
              (s.id && s.id.toLowerCase() === currentUsername))
        )
        .forEach(pushUnique);
    }

    if (isGuardianView) {
      // Match all siblings/children sharing the guardian's verified phone or primary child's guardian phone
      const primaryGuardianPhone = normalizePhone(list[0]?.guardianPhone || list[0]?.fatherPhone);
      const matchPhones = new Set<string>();
      if (isValidUserPhone) matchPhones.add(userPhoneNorm);
      if (primaryGuardianPhone.length >= 10 && primaryGuardianPhone !== '1700000000') {
        matchPhones.add(primaryGuardianPhone);
      }
      if (matchPhones.size > 0) {
        students
          .filter((s) => {
            if (!s) return false;
            return (
              matchPhones.has(normalizePhone(s.guardianPhone)) ||
              matchPhones.has(normalizePhone(s.fatherPhone)) ||
              matchPhones.has(normalizePhone(s.motherPhone))
            );
          })
          .forEach(pushUnique);
      }
      if (list.length === 0 && currentName && currentName !== 'guardian' && currentName !== 'guardian portal') {
        students
          .filter((s) => s && s.guardianName && s.guardianName.trim().toLowerCase() === currentName)
          .forEach(pushUnique);
      }
    } else if (list.length === 0 && currentName && currentName !== 'student' && currentName !== 'student portal') {
      pushUnique(students.find((s) => s && s.nameEn && s.nameEn.trim().toLowerCase() === currentName));
    }

    return list;
  }, [currentUser, students, isGuardianView]);

  const student: Student = useMemo(() => {
    if (matchedChildren.length > 0) {
      return matchedChildren.find((c) => c.id === selectedChildId) || matchedChildren[0];
    }

    return (
      students[0] || {
        id: 'std_default',
        studentId: 'S-2026-1004',
        nameEn: currentUser.name || 'Student',
        nameBn: currentUser.nameBn || 'শিক্ষার্থী',
        gender: 'Male',
        dob: '2010-01-01',
        bloodGroup: 'B+',
        religion: 'Islam',
        className: 'Class 10',
        section: 'A',
        shift: 'Day',
        roll: '04',
        session: '2026',
        fatherNameEn: 'Guardian',
        fatherNameBn: 'অভিভাবক',
        guardianName: 'Guardian',
        guardianPhone: '+880 1700-000000',
        guardianRelation: 'Father',
        presentAddress: 'Dhaka',
        permanentAddress: 'Dhaka',
        status: 'active',
        admissionDate: '2026-01-01',
      }
    );
  }, [matchedChildren, selectedChildId, students, currentUser]);

  // 1. ATTENDANCE DATA ISOLATION
  const studentAttendance: AttendanceRecord[] = useMemo(() => {
    return allAttendance.filter(
      (a) =>
        a &&
        a.targetType === 'student' &&
        (a.targetId === student.id || a.targetId === student.studentId || (a.rollOrEmpId === student.roll && a.className === student.className))
    ).sort((a, b) => (b.date || '').localeCompare(a.date || ''));
  }, [allAttendance, student]);

  const totalAttendanceDays = studentAttendance.length;
  const presentCount = studentAttendance.filter((a) => a.status === 'Present').length;
  const absentCount = studentAttendance.filter((a) => a.status === 'Absent').length;
  const lateCount = studentAttendance.filter((a) => a.status === 'Late').length;
  const excusedCount = studentAttendance.filter((a) => a.status === 'Excused').length;
  const attendanceRate = totalAttendanceDays > 0 ? Math.round((presentCount / totalAttendanceDays) * 100) : 100;

  // Real calendar date for current moment (YYYY-MM-DD in local time)
  // Ensures after midnight (12 AM) the date accurately turns to the new day
  const todayCalendarDate = useMemo(() => getLocalCalendarDateString(), []);

  // Strict Today's attendance: only matches today's real calendar date!
  // When midnight (12 AM) passes to the next day, this will be null until scanned or marked!
  const todayRecord = useMemo(() => {
    return studentAttendance.find((a) => a.date === todayCalendarDate) || null;
  }, [studentAttendance, todayCalendarDate]);

  // 2. HOMEWORK DATA ISOLATION
  const classHomework: Homework[] = useMemo(
    () => getClassHomeworkForStudent(allHomework, student),
    [allHomework, student]
  );

  const studentSubmissions: HomeworkSubmission[] = useMemo(() => {
    return allSubmissions.filter((s) => doesSubmissionBelongToStudent(s, student));
  }, [allSubmissions, student]);

  // Strict Homework Accounting for logged-in student (Tracks submitted, expired/missed, and active pending)
  const studentHwAccounting = useMemo(
    () => computeStudentHomeworkAccounting(classHomework, studentSubmissions, todayCalendarDate),
    [classHomework, studentSubmissions, todayCalendarDate]
  );

  // Homework Portal Sub-tab: 'assignments' | 'report'
  const [studentHwViewTab, setStudentHwViewTab] = useState<'assignments' | 'report'>('report');
  const [hwReportDateRange, setHwReportDateRange] = useState<'today' | 'this_week' | 'this_month' | 'this_year' | 'custom'>('today');
  const [hwReportStartDate, setHwReportStartDate] = useState<string>(() => {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-01`;
  });
  const [hwReportEndDate, setHwReportEndDate] = useState<string>(() => getLocalCalendarDateString());
  const [hwReportSubject, setHwReportSubject] = useState<string>('all');
  const [hwReportSearch, setHwReportSearch] = useState<string>('');
  const [hwReportSection, setHwReportSection] = useState<string>('all');

  // Homework Subjects for this student's class
  const classHwSubjects = useMemo(() => {
    const set = new Set<string>();
    allHomework.filter((h) => h.className === student.className).forEach((h) => {
      if (h.subjectName) set.add(h.subjectName);
    });
    return Array.from(set);
  }, [allHomework, student]);

  // STRICT STUDENT DATA ISOLATION: Calculate homework report strictly for the logged-in student's personal records
  const personalHwReport = useMemo(() => {
    const now = new Date();
    const todayStr = todayCalendarDate;
    let startDateStr = '';
    let endDateStr = todayStr;

    if (hwReportDateRange === 'today') {
      startDateStr = todayStr;
      endDateStr = todayStr;
    } else if (hwReportDateRange === 'this_week') {
      const d = new Date(now);
      const day = d.getDay();
      const diff = d.getDate() - day + (day === 0 ? -6 : 1);
      const start = new Date(d.setDate(diff));
      startDateStr = getLocalCalendarDateString(start);
    } else if (hwReportDateRange === 'this_month') {
      startDateStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-01`;
    } else if (hwReportDateRange === 'this_year') {
      startDateStr = `${now.getFullYear()}-01-01`;
    } else {
      startDateStr = hwReportStartDate;
      endDateStr = hwReportEndDate;
    }

    // Filter assignments strictly for this student's class and section in this period
    const periodHomework = allHomework.filter((h) => {
      if (h.className !== student.className) return false;
      const studentSectionOk = !h.section || h.section === 'all' || !student.section || h.section === student.section;
      if (!studentSectionOk) return false;
      const hDate = h.assignedDate || h.dueDate || '';
      const inDate =
        (hDate >= startDateStr && hDate <= endDateStr) ||
        (h.assignedDate <= endDateStr && h.dueDate >= startDateStr) ||
        (hwReportDateRange === 'today' && (h.assignedDate === todayStr || h.homeworkDate === todayStr));
      const matchSec = hwReportSection === 'all' || !h.section || h.section === 'all' || h.section === hwReportSection;
      const matchSub = hwReportSubject === 'all' || h.subjectName === hwReportSubject;
      return inDate && matchSec && matchSub;
    });

    const periodHwIds = new Set(periodHomework.map((h) => h.id));
    const totalPossibleMarks = periodHomework.reduce((acc, h) => acc + (h.fullMarks || 10), 0);

    // Only this student's submissions matching assignments in this period
    const mySubs = studentSubmissions.filter((sub) => periodHwIds.has(sub.homeworkId));
    const submittedCount = periodHomework.filter((hw) => mySubs.some((sub) => sub.homeworkId === hw.id)).length;
    let missedCount = 0;
    let activePendingCount = 0;

    periodHomework.forEach((hw) => {
      const hasSub = mySubs.some((sub) => sub.homeworkId === hw.id);
      if (!hasSub) {
        if (hw.dueDate && todayStr > hw.dueDate) {
          missedCount++;
        } else {
          activePendingCount++;
        }
      }
    });

    const obtainedMarks = mySubs.reduce((acc, sub) => {
      const m = sub.teacherMarks !== undefined ? sub.teacherMarks : sub.aiEvaluation?.suggestedMarks || 0;
      return acc + m;
    }, 0);

    const percentage = totalPossibleMarks > 0 ? Math.round((obtainedMarks / totalPossibleMarks) * 100) : 0;
    const submissionRate = periodHomework.length > 0 ? Math.round((submittedCount / periodHomework.length) * 100) : 0;

    // Subject breakdown for this student
    const subjectBreakdown = classHwSubjects.map((subName) => {
      const subHw = periodHomework.filter((h) => h.subjectName === subName);
      const subTotalMarks = subHw.reduce((acc, h) => acc + (h.fullMarks || 10), 0);
      const subSubs = mySubs.filter((s) => {
        const parent = periodHomework.find((h) => h.id === s.homeworkId);
        return parent?.subjectName === subName;
      });
      const subObtained = subSubs.reduce((acc, s) => {
        const m = s.teacherMarks !== undefined ? s.teacherMarks : s.aiEvaluation?.suggestedMarks || 0;
        return acc + m;
      }, 0);
      return {
        subjectName: subName,
        assignedCount: subHw.length,
        submittedCount: subSubs.length,
        obtainedMarks: subObtained,
        totalMarks: subTotalMarks,
        percentage: subTotalMarks > 0 ? Math.round((subObtained / subTotalMarks) * 100) : 0,
      };
    }).filter((s) => s.assignedCount > 0);

    return {
      startDateStr,
      endDateStr,
      periodHomework,
      totalAssigned: periodHomework.length,
      submittedCount,
      missedCount,
      activePendingCount,
      obtainedMarks,
      totalPossibleMarks,
      percentage,
      submissionRate,
      subjectBreakdown,
      submissions: mySubs,
    };
  }, [allHomework, studentSubmissions, student, hwReportDateRange, hwReportStartDate, hwReportEndDate, hwReportSubject, hwReportSection, classHwSubjects]);


  // Homework Submission Modal State
  const [submittingHw, setSubmittingHw] = useState<Homework | null>(null);
  const [submissionText, setSubmissionText] = useState<string>('');
  const [submissionImages, setSubmissionImages] = useState<string[]>([]);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [submissionMessage, setSubmissionMessage] = useState<string>('');
  const [submissionBlockReason, setSubmissionBlockReason] = useState<string>('');

  const handleOpenSubmit = (hw: Homework) => {
    const existing = studentSubmissions.find((s) => s.homeworkId === hw.id);
    // If deadline has passed and student hasn't submitted yet, reject submission
    if (!existing && hw.dueDate && todayCalendarDate > hw.dueDate) {
      setSubmissionBlockReason(
        `এই বাড়ির কাজের নির্ধারিত জমার শেষ তারিখ (${formatDate(hw.dueDate)}) উত্তীর্ণ হয়ে গেছে। সময়সীমা পার হওয়ার কারণে এটি আর জমা দেওয়া যাবে না।`
      );
      setTimeout(() => setSubmissionBlockReason(''), 6000);
      return;
    }

    setSubmittingHw(hw);
    if (existing) {
      setSubmissionText(existing.textAnswer || '');
      setSubmissionImages(existing.imageUrls || []);
    } else {
      setSubmissionText('');
      setSubmissionImages([]);
    }
    setSubmissionMessage('');
  };

  const [isEvaluatingAi, setIsEvaluatingAi] = useState<boolean>(false);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;
    Array.from(files).forEach(async (file) => {
      if (file.type.startsWith('image/')) {
        try {
          const compressed = await compressImageToPassportSize(file, 720, 960, 0.65);
          if (compressed) {
            setSubmissionImages((prev) => [...prev, compressed]);
            return;
          }
        } catch {}
      }
      const reader = new FileReader();
      reader.onload = (uploadEvent) => {
        if (uploadEvent.target?.result) {
          setSubmissionImages((prev) => [...prev, uploadEvent.target!.result as string]);
        }
      };
      reader.readAsDataURL(file);
    });
  };

  const persistHomeworkSubmission = async (sub: HomeworkSubmission): Promise<HomeworkSubmission> => {
    if (saasSession?.school?.schoolId) {
      try {
        const res = await SaaSApi.submitHomeworkSubmission(sub);
        if (res?.submissions && Array.isArray(res.submissions)) {
          StorageService.replaceHomeworkSubmissionsLocal(res.submissions);
          setSyncTick((n) => n + 1);
          return (res.submission as HomeworkSubmission) || sub;
        }
        if (res?.submission) {
          StorageService.upsertHomeworkSubmissionLocal(res.submission as HomeworkSubmission);
          setSyncTick((n) => n + 1);
          return res.submission as HomeworkSubmission;
        }
      } catch (apiErr: any) {
        if (!isSaaSBackendUnavailableError(apiErr)) {
          console.warn('Server homework submission sync warning:', apiErr);
        }
      }
    }
    const saved = StorageService.saveOrUpdateSubmission(sub, {
      skipCloudPush: Boolean(saasSession?.school?.schoolId),
    });
    setSyncTick((n) => n + 1);
    return saved;
  };

  const handleSubmitHomework = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!submittingHw || isSubmitting || isEvaluatingAi) return;

    const existingSub = studentSubmissions.find((s) => s.homeworkId === submittingHw.id);

    // Check deadline: if passed and no prior submission, cannot submit
    if (!existingSub && submittingHw.dueDate && todayCalendarDate > submittingHw.dueDate) {
      alert(
        language === 'bn'
          ? 'এই বাড়ির কাজের নির্ধারিত জমার সময় উত্তীর্ণ হয়ে গেছে। সময়সীমা পার হওয়ায় জমা গ্রহণ করা সম্ভব নয়।'
          : 'The submission deadline for this homework has expired.'
      );
      setSubmittingHw(null);
      return;
    }

    if (!submissionText.trim() && submissionImages.length === 0) {
      alert(language === 'bn' ? 'অনুগ্রহ করে খাতার ছবি অথবা উত্তর লিখুন।' : 'Please attach photos or write your answer.');
      return;
    }

    const targetHw = submittingHw;
    setIsSubmitting(true);
    setSubmissionMessage('');

    const newSub: HomeworkSubmission = {
      id: existingSub?.id || `sub_${Date.now()}_${student.id}`,
      homeworkId: targetHw.id,
      studentId: student.id,
      studentCode: student.studentId,
      studentName: student.nameEn || student.nameBn,
      studentRoll: student.roll,
      className: targetHw.className,
      section: targetHw.section || student.section,
      submissionDate: new Date().toISOString().replace('T', ' ').slice(0, 16),
      submissionType:
        submissionImages.length > 0 && submissionText.trim()
          ? 'mixed'
          : submissionImages.length > 0
          ? 'handwritten_image'
          : 'text',
      imageUrls: submissionImages,
      textAnswer: submissionText,
      status: 'submitted',
      version: existingSub ? (existingSub.version || 1) + 1 : 1,
    };

    // Save locally immediately so UI switches to Submitted right away, then persist to SaaS backend
    StorageService.upsertHomeworkSubmissionLocal(newSub);
    setSyncTick((n) => n + 1);
    const persistedSub = await persistHomeworkSubmission(newSub);

    setIsSubmitting(false);
    setIsEvaluatingAi(true);
    setSubmissionMessage(
      language === 'bn'
        ? 'হোমওয়ার্ক সফলভাবে জমা হয়েছে! এআই এখন আপনার উত্তর যাচাই ও মূল্যায়ন করছে...'
        : 'Homework submitted! AI is evaluating your answers...'
    );

    try {
      const res = await AIService.evaluateHomework({
        homework: targetHw,
        student,
        textAnswer: submissionText,
        images: submissionImages,
      });

      if (res.success && res.evaluation) {
        const evalData = res.evaluation;
        const fullMarks = targetHw.fullMarks || 10;
        const needsReview = Boolean(evalData.requiresTeacherReview || evalData.status === 'review_required');

        const updatedSub: HomeworkSubmission = needsReview
          ? {
              ...persistedSub,
              status: 'review_required',
              teacherFeedback: evalData.feedback,
              aiEvaluation: evalData,
            }
          : {
              ...persistedSub,
              status: 'approved',
              teacherMarks: evalData.suggestedMarks,
              teacherFeedback: evalData.feedback,
              reviewedBy: 'Gemini AI Evaluator (স্বয়ংক্রিয়)',
              reviewedAt: new Date().toISOString(),
              aiEvaluation: {
                ...evalData,
                requiresTeacherReview: false,
              },
            };

        StorageService.upsertHomeworkSubmissionLocal(updatedSub);
        await persistHomeworkSubmission(updatedSub);
        setSyncTick((n) => n + 1);

        setSubmissionMessage(
          needsReview
            ? language === 'bn'
              ? `হোমওয়ার্ক জমা হয়েছে! ${evalData.feedback || 'শিক্ষকের যাচাইয়ের জন্য পাঠানো হয়েছে।'}`
              : `Homework submitted and queued for teacher review.`
            : language === 'bn'
            ? `হোমওয়ার্ক সফলভাবে জমা ও মূল্যায়ন সম্পন্ন হয়েছে! প্রাপ্ত নম্বর: ${toBnNumber(evalData.suggestedMarks)} / ${toBnNumber(fullMarks)}`
            : `Homework submitted and graded! Score: ${evalData.suggestedMarks} / ${fullMarks}`
        );
      } else {
        const reviewSub: HomeworkSubmission = {
          ...persistedSub,
          status: 'review_required',
          teacherFeedback: res.message || 'এআই মূল্যায়ন সম্পন্ন হয়নি; শিক্ষকের যাচাইয়ের জন্য অপেক্ষমাণ।',
        };
        StorageService.upsertHomeworkSubmissionLocal(reviewSub);
        await persistHomeworkSubmission(reviewSub);
        setSyncTick((n) => n + 1);

        setSubmissionMessage(
          language === 'bn'
            ? 'হোমওয়ার্ক সফলভাবে জমা হয়েছে! এআই মূল্যায়ন এই মুহূর্তে পাওয়া যায়নি, শিক্ষকের রিভিউয়ের পর নম্বর যুক্ত হবে।'
            : 'Homework submitted successfully! Pending teacher review.'
        );
      }
    } finally {
      setIsEvaluatingAi(false);
    }
  };

  // 3. CLASS ROUTINE DATA ISOLATION (Strictly SuperAdmin-published routines only)
  const studentRoutines: RoutinePeriod[] = useMemo(() => {
    return allRoutines
      .filter(
        (r) =>
          r.className === student.className &&
          (!r.section || r.section === 'all' || r.section === student.section) &&
          isPublishedForStudents(r.approvalStatus)
      )
      .sort((a, b) => a.periodNumber - b.periodNumber);
  }, [allRoutines, student]);

  const routineDays: ('Saturday' | 'Sunday' | 'Monday' | 'Tuesday' | 'Wednesday' | 'Thursday')[] = [
    'Saturday',
    'Sunday',
    'Monday',
    'Tuesday',
    'Wednesday',
    'Thursday',
  ];

  const dayNamesBn: Record<string, string> = {
    Saturday: 'শনিবার',
    Sunday: 'রবিবার',
    Monday: 'সোমবার',
    Tuesday: 'মঙ্গলবার',
    Wednesday: 'বুধবার',
    Thursday: 'বৃহস্পতিবার',
  };

  // 4. NOTICES DATA ISOLATION
  const studentNotices: Notice[] = useMemo(() => {
    return allNotices.filter((n) => {
      if (!n) return false;
      const matchAudience = n.targetAudience === 'All' || n.targetAudience === 'Class';
      const matchClass = !n.targetClass || n.targetClass === student.className;
      return matchAudience && matchClass;
    }).sort((a, b) => (b.date || '').localeCompare(a.date || ''));
  }, [allNotices, student]);

  // 5. EXAM MARKSHEET & CLASS MERIT LIST (Strictly Published Exams Only — Drafts Hidden)
  const publishedExams = useMemo(() => {
    return allExams.filter((e) => e.isPublished === true);
  }, [allExams]);

  const [selectedExamId, setSelectedExamId] = useState<string>(() => {
    const pub = allExams.filter((e) => e.isPublished === true);
    return pub[0]?.id || '';
  });

  const currentExam = useMemo(() => {
    return publishedExams.find((e) => e.id === selectedExamId) || publishedExams[0] || null;
  }, [publishedExams, selectedExamId]);

  // Student's marks in selected published exam only (also excludes unpublished draft/pending/rejected marks)
  const studentMarks: MarksEntry[] = useMemo(() => {
    if (!currentExam || !currentExam.isPublished) return [];
    return allMarks.filter(
      (m) =>
        (m.studentId === student.id || m.studentId === student.studentId) &&
        (m.examId === currentExam.id || m.examId === currentExam.term) &&
        isPublishedForStudents(m.approvalStatus)
    );
  }, [allMarks, currentExam, student]);

  // Published Exam Routines & Strictly Personal Seat Plans for Active Student
  const {
    flatItems: studentPublishedExamRoutines,
    groups: studentPublishedExamRoutineGroups,
  } = useMemo(
    () => getPublishedExamRoutineGroupsForStudent(allExamRoutines, allExams, student),
    [allExamRoutines, allExams, student]
  );

  const studentPublishedSeatPlans = useMemo(
    () => getPublishedSeatPlansForStudent(allSeatPlans, allExams, student),
    [allSeatPlans, allExams, student]
  );

  // Class Merit List Calculation for student's class and section (Published exam & published marks only)
  const classMeritList = useMemo(() => {
    const classPeers = students.filter(
      (s) => s.className === student.className && (!student.section || s.section === student.section) && s.status === 'active'
    );

    if (!currentExam || !currentExam.isPublished) return [];

    const calculated = classPeers.map((peer) => {
      const pMarks = allMarks.filter(
        (m) =>
          (m.studentId === peer.id || m.studentId === peer.studentId) &&
          (m.examId === currentExam.id || m.examId === currentExam.term) &&
          isPublishedForStudents(m.approvalStatus)
      );
      const totalScore = pMarks.reduce((sum, m) => sum + m.total, 0);
      const hasFail = pMarks.some((m) => m.grade === 'F');
      const gpas = pMarks.map((m) => m.gpa);
      const gpaRes = calculateTotalGPA(gpas, hasFail);
      return {
        student: peer,
        totalScore,
        avgGpa: gpaRes.totalGPA,
        overallGrade: gpaRes.overallGrade,
        hasFail,
        subjectCount: pMarks.length,
      };
    });

    // Passing students sorted by GPA desc, then totalScore desc, then Roll asc
    const passed = calculated
      .filter((item) => !item.hasFail && item.subjectCount > 0)
      .sort((a, b) => {
        if (b.avgGpa !== a.avgGpa) return b.avgGpa - a.avgGpa;
        if (b.totalScore !== a.totalScore) return b.totalScore - a.totalScore;
        return Number(a.student.roll) - Number(b.student.roll);
      });

    // Failed students
    const failed = calculated
      .filter((item) => item.hasFail || item.subjectCount === 0)
      .sort((a, b) => {
        if (b.totalScore !== a.totalScore) return b.totalScore - a.totalScore;
        return Number(a.student.roll) - Number(b.student.roll);
      });

    const ranked = [...passed, ...failed];

    return ranked.map((item, idx) => ({
      ...item,
      rank: idx + 1,
      isCurrentStudent: item.student.id === student.id || item.student.studentId === student.studentId,
    }));
  }, [students, student, publishedExams, allMarks, currentExam]);

  const currentStudentRank = currentExam?.isPublished
    ? (classMeritList.find((m) => m.isCurrentStudent)?.rank || null)
    : null;

  // Online Fee Payment Requests & School MFS Settings
  const [onlineRequests, setOnlineRequests] = useState<OnlinePaymentRequest[]>(() =>
    StorageService.getOnlinePaymentRequests()
  );
  const [mfsSettings, setMfsSettings] = useState<MfsPaymentSettings>(() =>
    StorageService.getMfsSettings()
  );

  // 6. FEE STATEMENT & DUES DATA ISOLATION (Derived safely via useMemo — avoids useEffect setState loops)
  const studentDues: FeeItem[] = useMemo(
    () => StorageService.getStudentDueFees(student),
    [student, syncTick, onlineRequests]
  );

  useEffect(() => {
    const handleSync = () => {
      setSyncTick((n) => n + 1);
      setOnlineRequests(StorageService.getOnlinePaymentRequests());
      setMfsSettings(StorageService.getMfsSettings());
    };
    window.addEventListener('school_cloud_data_synced', handleSync);
    return () => window.removeEventListener('school_cloud_data_synced', handleSync);
  }, []);

  const studentPayments = useMemo(() => {
    return allPayments.filter(
      (p) =>
        p &&
        (p.studentId === student.id ||
          p.studentId === student.studentId ||
          p.studentName?.toLowerCase() === student.nameEn.toLowerCase() ||
          p.studentName === student.nameBn)
    );
  }, [allPayments, student]);

  const studentInvoices: FeeInvoice[] = useMemo(() => {
    return allInvoices.filter(
      (inv) =>
        inv &&
        (inv.studentId === student.id ||
          inv.studentId === student.studentId ||
          (inv.roll === student.roll && inv.className === student.className))
    ).sort((a, b) => (b.dueDate || '').localeCompare(a.dueDate || ''));
  }, [allInvoices, student]);

  // Unified paid records to prevent duplicate rows for the same fee payment
  const unifiedPaidRecords = useMemo(() => {
    const list: Array<{
      id: string;
      invoiceNo?: string;
      receiptNo: string;
      displayNo: string;
      feeTitle: string;
      date: string;
      amount: number;
      method: string;
      status: string;
    }> = [];

    const matchedInvoiceIds = new Set<string>();

    // Prioritize actual payment receipts
    studentPayments.forEach((p) => {
      let matchingInv = studentInvoices.find(
        (inv) =>
          !matchedInvoiceIds.has(inv.id) &&
          (inv.id === p.invoiceId || (inv.invoiceNo && p.receiptNo === inv.invoiceNo))
      );

      // Legacy online approval fallback: invoiceId differed by a few ms when both payment & invoice were created together
      if (!matchingInv && p.notes?.includes('অনলাইন পেমেন্ট অনুমোদন')) {
        matchingInv = studentInvoices.find(
          (inv) =>
            !matchedInvoiceIds.has(inv.id) &&
            !studentPayments.some((other) => other.invoiceId === inv.id) &&
            inv.paidAmount === p.amount &&
            inv.dueDate === p.paidDate &&
            Boolean(inv.feeType) &&
            p.notes!.includes(inv.feeType)
        );
      }

      if (matchingInv) {
        matchedInvoiceIds.add(matchingInv.id);
      }

      list.push({
        id: p.id,
        invoiceNo: matchingInv?.invoiceNo,
        receiptNo: p.receiptNo,
        displayNo: p.receiptNo + (matchingInv?.invoiceNo ? ` (${matchingInv.invoiceNo})` : ''),
        feeTitle: matchingInv?.feeType || p.notes || 'School Fee Payment',
        date: p.paidDate,
        amount: p.amount,
        method: p.paymentMethod || 'Cash',
        status: 'পরিশোধিত',
      });
    });

    // Invoices with paidAmount > 0 that do not have a matching payment record in studentPayments
    studentInvoices.forEach((inv) => {
      if (inv.paidAmount > 0 && !matchedInvoiceIds.has(inv.id)) {
        const alreadyLinked = studentPayments.some(
          (p) => p.invoiceId === inv.id || p.receiptNo === inv.invoiceNo
        );
        if (!alreadyLinked) {
          list.push({
            id: inv.id,
            invoiceNo: inv.invoiceNo,
            receiptNo: inv.invoiceNo,
            displayNo: inv.invoiceNo,
            feeTitle: inv.feeType,
            date: inv.dueDate,
            amount: inv.paidAmount,
            method: 'Online/Counter',
            status: inv.dueAmount === 0 ? 'পরিশোধিত' : 'আংশিক পরিশোধিত',
          });
        }
      }
    });

    return list.sort((a, b) => (b.date || '').localeCompare(a.date || ''));
  }, [studentPayments, studentInvoices]);

  const totalFeePaid = useMemo(() => {
    const fromPayments = studentPayments.reduce((sum, p) => sum + (Number(p.amount) || 0), 0);
    const fromInvoices = studentInvoices.reduce((sum, inv) => sum + (inv.paidAmount || 0), 0);
    return Math.max(fromPayments, fromInvoices);
  }, [studentPayments, studentInvoices]);

  const totalFeeDue = useMemo(() => {
    const dueFromItems = studentDues.reduce((sum, d) => sum + (Number(d.amount) || 0), 0);
    const dueFromInvoices = studentInvoices.reduce((sum, inv) => sum + (inv.dueAmount || 0), 0);
    return dueFromItems > 0 ? dueFromItems : dueFromInvoices;
  }, [studentDues, studentInvoices]);

  const totalFeeBilled = totalFeePaid + totalFeeDue;

  useEffect(() => {
    const handleOnlinePaymentsUpdate = () => {
      setOnlineRequests(StorageService.getOnlinePaymentRequests());
      setSyncTick((n) => n + 1);
    };
    const handleMfsUpdate = () => {
      setMfsSettings(StorageService.getMfsSettings());
    };
    window.addEventListener('online_payments_updated', handleOnlinePaymentsUpdate);
    window.addEventListener('mfs_settings_updated', handleMfsUpdate);
    return () => {
      window.removeEventListener('online_payments_updated', handleOnlinePaymentsUpdate);
      window.removeEventListener('mfs_settings_updated', handleMfsUpdate);
    };
  }, []);

  const studentOnlineRequests = useMemo(() => {
    return onlineRequests.filter(
      (r) =>
        r &&
        (r.studentId === student.id ||
          r.studentId === student.studentId ||
          (r.studentRoll === student.roll && r.className === student.className))
    ).sort((a, b) => (b.requestDate || '').localeCompare(a.requestDate || ''));
  }, [onlineRequests, student]);

  // Online Fee Payment Modal State - bKash, Nagad & Rocket ONLY (No Cash)
  const [payingDue, setPayingDue] = useState<FeeItem | 'all' | null>(null);
  const [paymentMethod, setPaymentMethod] = useState<'bKash' | 'Nagad' | 'Rocket'>('bKash');
  const [paymentPhone, setPaymentPhone] = useState<string>(student.guardianPhone || student.fatherPhone || currentUser.phone || '');
  const [paymentTrxId, setPaymentTrxId] = useState<string>('');
  const [paymentError, setPaymentError] = useState<string | null>(null);
  const [isProcessingPayment, setIsProcessingPayment] = useState<boolean>(false);
  const [paymentRequestSubmitted, setPaymentRequestSubmitted] = useState<{
    receiptNo: string;
    amount: number;
    feeTitle: string;
    method: 'bKash' | 'Nagad' | 'Rocket';
    trxId: string;
    senderPhone: string;
  } | null>(null);

  const [paymentSuccessReceipt, setPaymentSuccessReceipt] = useState<{
    receiptNo: string;
    amount: number;
    feeTitle: string;
    date: string;
    method: string;
  } | null>(null);

  const openPaymentModal = (target: FeeItem | 'all') => {
    setPaymentPhone(student.guardianPhone || student.fatherPhone || currentUser.phone || '');
    setPaymentTrxId('');
    setPaymentError(null);
    setPayingDue(target);
  };

  const handleProcessPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!payingDue || isProcessingPayment) return;
    setPaymentError(null);

    if (!paymentPhone.trim()) {
      setPaymentError(language === 'bn' ? 'অনুগ্রহ করে প্রেরক মোবাইল নম্বর দিন।' : 'Please enter sender mobile number.');
      return;
    }

    if (!paymentTrxId.trim()) {
      setPaymentError(
        language === 'bn'
          ? 'অনুগ্রহ করে বিকাশ, নগদ বা রকেট ট্রানজেকশন আইডি (TrxID) লিখুন।'
          : 'Please enter Transaction ID (TrxID).'
      );
      return;
    }

    const cleanTrx = paymentTrxId.trim().toUpperCase();
    const existingDup = onlineRequests.find(
      (r) => r && String(r.transactionId || '').trim().toUpperCase() === cleanTrx && r.status !== 'rejected'
    );
    if (existingDup) {
      setPaymentError(
        language === 'bn'
          ? 'এই ট্রানজেকশন আইডি (TrxID) দিয়ে ইতিমধ্যে আবেদন করা হয়েছে। সঠিক TrxID দিন।'
          : 'This Transaction ID has already been submitted.'
      );
      return;
    }

    setIsProcessingPayment(true);
    const amountToPay = payingDue === 'all' ? totalFeeDue : payingDue.amount;
    const isPayAll = payingDue === 'all';
    const itemsToPay: FeeItem[] = isPayAll ? studentDues : [payingDue];
    const feeTitle = isPayAll ? 'সকল বকেয়া ফি (All Outstanding Dues)' : payingDue.headName;
    const receiptNo = `REQ-${Date.now().toString().slice(-6)}`;

    const newRequest: OnlinePaymentRequest = {
      id: `opr_${Date.now()}`,
      receiptNo,
      studentId: student.id,
      studentName: student.nameBn || student.nameEn,
      studentRoll: student.roll,
      className: student.className,
      section: student.section,
      feeTitle,
      amount: amountToPay,
      items: itemsToPay,
      isPayAll,
      paymentMethod,
      senderPhone: paymentPhone.trim(),
      transactionId: cleanTrx,
      requestDate: new Date().toISOString().split('T')[0],
      status: 'pending',
      notes: `Guardian online payment request via ${paymentMethod}`,
    };

    try {
      let savedViaServer = false;
      if (saasSession?.school?.schoolId) {
        try {
          const res = await SaaSApi.submitOnlineFeePayment(newRequest);
          if (res?.request) {
            StorageService.upsertOnlinePaymentRequestLocal(res.request);
            savedViaServer = true;
          }
        } catch (apiErr: any) {
          if (!isSaaSBackendUnavailableError(apiErr)) {
            setPaymentError(
              apiErr?.message ||
                (language === 'bn'
                  ? 'অনলাইন পেমেন্ট রিকোয়েস্ট পাঠাতে সমস্যা হয়েছে।'
                  : 'Failed to submit online payment request.')
            );
            setIsProcessingPayment(false);
            return;
          }
        }
      }

      if (!savedViaServer) {
        StorageService.addOnlinePaymentRequest(newRequest);
      }

      setOnlineRequests(StorageService.getOnlinePaymentRequests());
      setPayingDue(null);
      setPaymentRequestSubmitted({
        receiptNo,
        amount: amountToPay,
        feeTitle,
        method: paymentMethod,
        trxId: cleanTrx,
        senderPhone: paymentPhone.trim(),
      });
      setPaymentTrxId('');
    } finally {
      setIsProcessingPayment(false);
    }
  };

  // Saturday Weekend / Working day listener
  const [isSaturdayOff, setIsSaturdayOff] = useState<boolean>(() => StorageService.isSaturdayOff());
  useEffect(() => {
    const handleSaturdayToggle = () => {
      setIsSaturdayOff(StorageService.isSaturdayOff());
    };
    window.addEventListener('saturday_off_toggled', handleSaturdayToggle);
    return () => window.removeEventListener('saturday_off_toggled', handleSaturdayToggle);
  }, []);

  const portalLauncherItems: LauncherTileItem[] = [
    {
      id: 'overview',
      label: language === 'bn' ? 'সারসংক্ষেপ' : 'Overview',
      icon: TrendingUp,
      color: 'blue',
      active: activeSubTab === 'overview',
      onClick: () => setActiveSubTab('overview'),
    },
    {
      id: 'attendance',
      label: isGuardianView ? 'সন্তানের হাজিরা' : 'আমার হাজিরা',
      icon: CalendarCheck2,
      color: 'green',
      active: activeSubTab === 'attendance',
      onClick: () => setActiveSubTab('attendance'),
    },
    {
      id: 'homework',
      label: language === 'bn' ? 'বাড়ির কাজ' : 'Homework',
      icon: BookOpen,
      color: 'amber',
      badge: studentHwAccounting.dueTotal > 0 ? studentHwAccounting.dueTotal : undefined,
      active: activeSubTab === 'homework',
      onClick: () => setActiveSubTab('homework'),
    },
    {
      id: 'routine',
      label: language === 'bn' ? 'ক্লাস রুটিন' : 'Class Routine',
      icon: CalendarDays,
      color: 'sky',
      active: activeSubTab === 'routine',
      onClick: () => setActiveSubTab('routine'),
    },
    {
      id: 'exam_routine',
      label: language === 'bn' ? 'পরীক্ষার রুটিন' : 'Exam Routine',
      icon: Calendar,
      color: 'teal',
      badge:
        studentPublishedExamRoutines.length > 0
          ? toBnNumber(studentPublishedExamRoutines.length)
          : studentPublishedSeatPlans.length > 0
          ? '✓'
          : undefined,
      active: activeSubTab === 'exam_routine',
      onClick: () => setActiveSubTab('exam_routine'),
    },
    {
      id: 'notices',
      label: language === 'bn' ? 'নোটিশ বোর্ড' : 'Notices',
      icon: Bell,
      color: 'red',
      badge: studentNotices.length > 0 ? studentNotices.length : undefined,
      active: activeSubTab === 'notices',
      onClick: () => setActiveSubTab('notices'),
    },
    {
      id: 'exams',
      label: language === 'bn' ? 'ফলাফল ও মার্কস' : 'Results',
      icon: Award,
      color: 'purple',
      active: activeSubTab === 'exams',
      onClick: () => setActiveSubTab('exams'),
    },
    ...(isGuardianView
      ? [
          {
            id: 'fees',
            label: language === 'bn' ? 'ফি স্টেটমেন্ট' : 'Fee Statement',
            icon: Wallet,
            color: 'green' as const,
            active: activeSubTab === 'fees',
            onClick: () => setActiveSubTab('fees'),
          },
        ]
      : []),
    {
      id: 'blogs',
      label: language === 'bn' ? 'স্কুল ব্লগ' : 'School Blogs',
      icon: Newspaper,
      color: 'indigo',
      badge: publishedBlogs.length > 0 ? toBnNumber(publishedBlogs.length) : undefined,
      active: activeSubTab === 'blogs',
      onClick: () => setActiveSubTab('blogs'),
    },
  ];

  return (
    <div className="space-y-5">
      {/* 1. Navigation Launcher Grid */}
      <LauncherIconGrid items={portalLauncherItems} columns={5} />

      {/* 2. Clean White Student / Guardian Profile Bar */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-4 sm:p-5">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center space-x-3.5">
            <div className="w-14 h-16 rounded-xl border border-slate-200 bg-slate-100 overflow-hidden shadow-2xs shrink-0">
              {student.photoUrl ? (
                <img src={student.photoUrl} alt={student.nameEn || 'Student'} className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex items-center justify-center font-black text-xl text-blue-700 bg-blue-50">
                  {(student.nameEn || student.nameBn || 'S').charAt(0)}
                </div>
              )}
            </div>

            <div>
              <div className="text-[11px] font-bold text-blue-700 flex items-center space-x-1">
                <ShieldCheck className="w-3.5 h-3.5 text-blue-600" />
                <span>
                  {isGuardianView
                    ? 'অভিভাবক ও শিক্ষার্থী পোর্টাল'
                    : 'শিক্ষার্থী পোর্টাল'}
                </span>
              </div>
              <h2 className="text-lg sm:text-xl font-extrabold text-slate-900 mt-0.5">
                {student.nameBn || student.nameEn}
              </h2>
              <p className="text-xs text-slate-500 font-medium">
                {student.nameEn}
                {isGuardianView && (student.guardianName || student.fatherNameBn)
                  ? ` • অভিভাবক: ${student.guardianName || student.fatherNameBn}`
                  : ''}
              </p>
              <div className="flex flex-wrap items-center gap-1.5 mt-2 text-[11px]">
                <span className="px-2 py-0.5 rounded-md bg-blue-50 border border-blue-200 text-blue-800 font-bold">
                  ID: {student.studentId}
                </span>
                <span className="px-2 py-0.5 rounded-md bg-slate-100 border border-slate-200 text-slate-700 font-semibold">
                  {student.className} ({student.section}) • রোল {student.roll}
                </span>
                <span className="px-2 py-0.5 rounded-md bg-emerald-50 border border-emerald-200 text-emerald-800 font-bold">
                  মেধা স্থান: {currentStudentRank !== null ? `${toBnNumber(currentStudentRank)}ম` : 'অপ্রকাশিত'}
                </span>
                <button
                  type="button"
                  onClick={() => setShowStudentCredsModal(true)}
                  className="px-2 py-0.5 rounded-md bg-purple-50 hover:bg-purple-100 text-purple-700 font-bold inline-flex items-center space-x-1 border border-purple-200 transition-colors"
                >
                  <KeyRound className="w-3 h-3" />
                  <span>{language === 'bn' ? 'পাসওয়ার্ড' : 'Password'}</span>
                </button>
              </div>
            </div>
          </div>

          {/* Quick Metrics */}
          <div className={`grid ${isGuardianView ? 'grid-cols-3' : 'grid-cols-2'} gap-2 text-center bg-slate-50 p-2.5 rounded-xl border border-slate-200/80`}>
            <div className="px-3 py-1.5">
              <span className="text-[10px] text-slate-500 block font-semibold">উপস্থিতি</span>
              <span className={`text-base font-extrabold tabular-nums ${attendanceRate >= 80 ? 'text-emerald-600' : attendanceRate >= 60 ? 'text-amber-600' : 'text-rose-600'}`}>
                {toBnNumber(attendanceRate)}%
              </span>
            </div>
            <div className={`px-3 py-1.5 ${isGuardianView ? 'border-x border-slate-200' : 'border-l border-slate-200'}`}>
              <span className="text-[10px] text-slate-500 block font-semibold">বাড়ির কাজ</span>
              <span className="text-base font-extrabold text-slate-900 tabular-nums">
                {toBnNumber(studentHwAccounting.submitted)}/{toBnNumber(studentHwAccounting.total)}
              </span>
            </div>
            {isGuardianView && (
              <div className="px-3 py-1.5">
                <span className="text-[10px] text-slate-500 block font-semibold">বকেয়া ফি</span>
                <span className={`text-base font-extrabold tabular-nums ${totalFeeDue > 0 ? 'text-rose-600' : 'text-emerald-600'}`}>
                  {formatTaka(totalFeeDue)}
                </span>
              </div>
            )}
          </div>
        </div>

        {/* Multi-child selector bar when Guardian has 2+ linked children */}
        {matchedChildren.length > 1 && (
          <div className="mt-3.5 pt-3 border-t border-slate-100 flex flex-wrap items-center gap-2">
            <span className="text-[11px] font-bold text-slate-600">
              সন্তান নির্বাচন ({toBnNumber(matchedChildren.length)} জন):
            </span>
            {matchedChildren.map((child) => {
              const isSelected = child.id === student.id;
              return (
                <button
                  key={child.id}
                  type="button"
                  onClick={() => setSelectedChildId(child.id)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all border ${
                    isSelected
                      ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                      : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  {child.nameBn || child.nameEn} ({child.className} • রোল {child.roll})
                </button>
              );
            })}
          </div>
        )}
      </div>

      {/* ===================================================================== */}
      {/* TAB 1: OVERVIEW SUMMARY                                                */}
      {/* ===================================================================== */}
      {activeSubTab === 'overview' && (
        <div className="space-y-6">
          {/* Summary Cards (4 for Guardian including Fees, 3 for Student without Fees) */}
          <div className={`grid grid-cols-1 ${isGuardianView ? 'sm:grid-cols-2 lg:grid-cols-4' : 'sm:grid-cols-3'} gap-4`}>
            {/* 1. আজকের হাজিরা Card */}
            <div
              className={`p-4 rounded-2xl border shadow-xs transition-colors ${
                todayRecord?.status === 'Absent'
                  ? 'bg-rose-50/70 border-rose-200'
                  : todayRecord?.status === 'Late'
                  ? 'bg-amber-50/70 border-amber-200'
                  : todayRecord?.status === 'Present'
                  ? 'bg-emerald-50/50 border-emerald-200'
                  : 'bg-amber-50/40 border-amber-200'
              }`}
            >
              <div className="flex items-center justify-between text-xs font-bold">
                <span
                  className={
                    todayRecord?.status === 'Absent'
                      ? 'text-rose-800'
                      : todayRecord?.status === 'Late'
                      ? 'text-amber-800'
                      : todayRecord?.status === 'Present'
                      ? 'text-emerald-800'
                      : 'text-amber-800'
                  }
                >
                  আজকের হাজিরা ({formatDate(todayCalendarDate)})
                </span>
                {todayRecord?.status === 'Absent' ? (
                  <XCircle className="w-4 h-4 text-rose-600" />
                ) : todayRecord?.status === 'Late' ? (
                  <Clock className="w-4 h-4 text-amber-600" />
                ) : todayRecord?.status === 'Present' ? (
                  <CalendarCheck2 className="w-4 h-4 text-emerald-600" />
                ) : (
                  <Clock className="w-4 h-4 text-amber-600" />
                )}
              </div>
              <div className="mt-2.5 flex items-center justify-between">
                <span
                  className={`text-base sm:text-lg font-black ${
                    todayRecord?.status === 'Absent'
                      ? 'text-rose-600'
                      : todayRecord?.status === 'Late'
                      ? 'text-amber-600'
                      : todayRecord?.status === 'Present'
                      ? 'text-emerald-700'
                      : 'text-amber-700'
                  }`}
                >
                  {todayRecord?.status === 'Absent'
                    ? 'অনুপস্থিত (Absent)'
                    : todayRecord?.status === 'Late'
                    ? 'দেরিতে উপস্থিতি (Late)'
                    : todayRecord?.status === 'Present'
                    ? 'উপস্থিত (Present)'
                    : 'আজ এখনও উপস্থিতি নিশ্চিত করা হয়নি'}
                </span>
                <span
                  className={`px-2.5 py-0.5 rounded-full text-[10px] font-black border ${
                    todayRecord?.status === 'Absent'
                      ? 'bg-rose-100 text-rose-700 border-rose-300'
                      : todayRecord?.status === 'Late'
                      ? 'bg-amber-100 text-amber-800 border-amber-300'
                      : todayRecord?.status === 'Present'
                      ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
                      : 'bg-amber-100 text-amber-800 border-amber-300'
                  }`}
                >
                  {todayRecord?.status === 'Absent'
                    ? 'অনুপস্থিত'
                    : todayRecord?.status === 'Late'
                    ? 'দেরিতে উপস্থিতি'
                    : todayRecord?.status === 'Present'
                    ? todayRecord?.scanTime || 'উপস্থিত ✓'
                    : 'হাজিরা বা স্ক্যান বাকি'}
                </span>
              </div>
              <p
                className={`text-[11px] mt-1.5 font-medium ${
                  todayRecord?.status === 'Absent'
                    ? 'text-rose-600'
                    : todayRecord?.status === 'Late'
                    ? 'text-amber-700'
                    : todayRecord?.status === 'Present'
                    ? 'text-emerald-600'
                    : 'text-amber-700'
                }`}
              >
                {todayRecord?.status === 'Absent'
                  ? todayRecord.remarks || 'শ্রেণিকক্ষে অনুপস্থিত হিসেবে নথিভুক্ত করা হয়েছে'
                  : todayRecord?.status === 'Late' || todayRecord?.status === 'Present'
                  ? `${todayRecord.status === 'Late' ? 'দেরিতে চেক-ইন' : 'চেক-ইন'}: ${todayRecord.inTime || todayRecord.scanTime || '০৮:২৫ AM'}${todayRecord.outTime ? ` • চেক-আউট: ${todayRecord.outTime}` : ''}${todayRecord.stayDuration ? ` (${todayRecord.stayDuration})` : ''} (${todayRecord.method === 'face_scan' ? 'AI ফেস স্ক্যান' : todayRecord.method === 'qr_scanner' ? 'QR স্ক্যান' : 'শ্রেণিকক্ষ হাজিরা'})`
                  : 'আজকের ক্লাসের হাজিরা এখনও নেওয়া হয়নি বা কিউআর/ফেস স্ক্যান করা হয়নি। হাজিরা সম্পন্ন হলে এখানে স্ট্যাটাস আপডেট হবে।'}
              </p>
            </div>

            <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs">
              <div className="flex items-center justify-between text-slate-500 text-xs font-bold">
                <span>বাড়ির কাজের হিসাব ও স্ট্যাটাস</span>
                <BookOpen className="w-4 h-4 text-amber-600" />
              </div>
              <div className="mt-3 flex items-center justify-between">
                <div>
                  <span className="text-2xl font-black text-slate-900">
                    {toBnNumber(studentHwAccounting.dueTotal)} টি বাকি
                  </span>
                  <div className="flex items-center gap-1.5 mt-1 text-[10px] font-bold">
                    {studentHwAccounting.expiredCount > 0 ? (
                      <span className="text-rose-600 bg-rose-50 px-1.5 py-0.5 rounded border border-rose-200">
                        {toBnNumber(studentHwAccounting.expiredCount)}টি মিসড (সময় উত্তীর্ণ)
                      </span>
                    ) : (
                      <span className="text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded">
                        কোনো মিসড নেই
                      </span>
                    )}
                    <span className="text-blue-600">
                      • {toBnNumber(studentHwAccounting.submitted)}টি জমা
                    </span>
                  </div>
                </div>
                <button
                  onClick={() => setActiveSubTab('homework')}
                  className="text-xs font-bold text-amber-600 hover:underline shrink-0"
                >
                  বিবরণ &rarr;
                </button>
              </div>
            </div>

            <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs">
              <div className="flex items-center justify-between text-slate-500 text-xs font-bold">
                <span>শ্রেণি মেধা ক্রম</span>
                <Award className="w-4 h-4 text-indigo-600" />
              </div>
              <div className="mt-3 flex items-center justify-between">
                <span className="text-xl sm:text-2xl font-black text-indigo-700">
                  {currentStudentRank !== null ? `${toBnNumber(currentStudentRank)}ম স্থান` : 'অপ্রকাশিত'}
                </span>
                <span className="text-xs font-semibold text-slate-500">
                  {student.className} ({student.section})
                </span>
              </div>
            </div>

            {isGuardianView && (
              <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs">
                <div className="flex items-center justify-between text-slate-500 text-xs font-bold">
                  <span>ফি স্টেটমেন্ট বকেয়া</span>
                  <Wallet className="w-4 h-4 text-rose-600" />
                </div>
                <div className="mt-3 flex items-center justify-between">
                  <span className={`text-xl font-black ${totalFeeDue > 0 ? 'text-rose-600' : 'text-emerald-600'}`}>
                    {formatTaka(totalFeeDue)}
                  </span>
                  <button
                    onClick={() => setActiveSubTab('fees')}
                    className="text-xs font-bold text-rose-600 hover:underline"
                  >
                    {totalFeeDue > 0 ? `${toBnNumber(studentDues.length)}টি বকেয়া পরিশোধ →` : 'বিবরণী →'}
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Published Exam Routine & Personal Seat Plan Highlight Banner */}
          {(studentPublishedExamRoutines.length > 0 || studentPublishedSeatPlans.length > 0) && (
            <div className="p-4 rounded-2xl border border-indigo-200 bg-gradient-to-r from-indigo-50 via-blue-50 to-emerald-50/60 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-start sm:items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center shrink-0 shadow-xs">
                  <Calendar className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex flex-wrap items-center gap-2">
                    <h3 className="text-sm font-black text-slate-900">
                      {language === 'bn'
                        ? `পরীক্ষার রুটিন ও ব্যক্তিগত আসন প্রকাশিত হয়েছে (${student.className})`
                        : `Published Exam Routine & Your Seat Plan (${student.className})`}
                    </h3>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                      {language === 'bn' ? 'প্রকাশিত' : 'Published'}
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 mt-0.5">
                    {studentPublishedExamRoutines.length > 0
                      ? `${toBnNumber(studentPublishedExamRoutines.length)}টি বিষয়ের পরীক্ষার সময়সূচি`
                      : 'রুটিন অপেক্ষমাণ'}
                    {studentPublishedSeatPlans.length > 0
                      ? ` • নির্ধারিত আসন: ${studentPublishedSeatPlans[0].room?.roomNo || studentPublishedSeatPlans[0].assignment.roomNo} (${studentPublishedSeatPlans[0].assignment.seatLabel || `বেঞ্চ ${toBnNumber(studentPublishedSeatPlans[0].assignment.benchNumber)}`})`
                      : ' • আসন বিন্যাস এখনো প্রকাশিত হয়নি'}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setActiveSubTab('exam_routine')}
                className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-xs transition-colors shrink-0 inline-flex items-center justify-center gap-1.5"
              >
                <span>{language === 'bn' ? 'রুটিন ও আমার আসন দেখুন' : 'View Routine & My Seat'}</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* Quick Modules Row */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Recent Homework Preview */}
            <div className="p-5 bg-white rounded-2xl border border-slate-200 shadow-xs">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-extrabold text-slate-900 text-sm flex items-center gap-2">
                  <BookOpen className="w-4 h-4 text-blue-600" />
                  <span>সাম্প্রতিক বাড়ির কাজ ({student.className})</span>
                </h3>
                <button
                  onClick={() => setActiveSubTab('homework')}
                  className="text-xs font-bold text-blue-600 hover:underline"
                >
                  সকল বাড়ির কাজ &rarr;
                </button>
              </div>

              <div className="space-y-3">
                {classHomework.slice(0, 3).map((hw) => {
                  const sub = studentSubmissions.find((s) => s.homeworkId === hw.id);
                  const isExpired = !sub && hw.dueDate && todayCalendarDate > hw.dueDate;

                  return (
                    <div
                      key={hw.id}
                      className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between text-xs"
                    >
                      <div>
                        <h4 className="font-bold text-slate-900">{hw.title}</h4>
                        <p className="text-[11px] text-slate-500">
                          {hw.subjectName} • শেষ সময়: {formatDate(hw.dueDate)}
                        </p>
                      </div>
                      <div>
                        {sub ? (
                          <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
                            {sub.teacherMarks !== undefined || (sub.aiEvaluation && !sub.aiEvaluation.requiresTeacherReview)
                              ? `জমা দেওয়া হয়েছে (${toBnNumber(sub.teacherMarks ?? sub.aiEvaluation?.suggestedMarks ?? 0)}/${toBnNumber(hw.fullMarks || 10)})`
                              : sub.status === 'review_required'
                              ? 'জমা দেওয়া হয়েছে (রিভিউ অপেক্ষমাণ)'
                              : 'জমা দেওয়া হয়েছে (মূল্যায়ন চলছে)'}
                          </span>
                        ) : isExpired ? (
                          <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-rose-100 text-rose-800 border border-rose-200 inline-flex items-center gap-1">
                            <Lock className="w-3 h-3 text-rose-600" />
                            <span>সময় উত্তীর্ণ (জমা বন্ধ)</span>
                          </span>
                        ) : (
                          <button
                            onClick={() => handleOpenSubmit(hw)}
                            className="px-3 py-1 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-[11px] font-bold shadow-xs"
                          >
                            জমা দিন
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* School & Class Notices Preview */}
            <div className="p-5 bg-white rounded-2xl border border-slate-200 shadow-xs">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-extrabold text-slate-900 text-sm flex items-center gap-2">
                  <Bell className="w-4 h-4 text-amber-500" />
                  <span>নোটিশ বোর্ড ({student.className} ও সাধারণ)</span>
                </h3>
                <button
                  onClick={() => setActiveSubTab('notices')}
                  className="text-xs font-bold text-blue-600 hover:underline"
                >
                  সকল নোটিশ &rarr;
                </button>
              </div>

              <div className="space-y-3">
                {studentNotices.slice(0, 3).map((n) => (
                  <div key={n.id} className="p-3 bg-amber-50/50 rounded-xl border border-amber-200 text-xs">
                    <div className="flex items-center justify-between">
                      <h4 className="font-bold text-slate-900">{n.title}</h4>
                      <span className="text-[10px] text-slate-500 font-semibold">{formatDate(n.date)}</span>
                    </div>
                    <p className="text-slate-600 mt-1 line-clamp-1">{n.content}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* School Blogs Preview (Read-Only) */}
          <div className="p-5 bg-white rounded-2xl border border-slate-200 shadow-xs">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <h3 className="font-extrabold text-slate-900 text-sm flex items-center gap-2">
                  <Newspaper className="w-4 h-4 text-indigo-600" />
                  <span>{language === 'bn' ? 'স্কুলের সাম্প্রতিক ব্লগ পোস্ট (School Blogs)' : 'Recent School Blog Posts'}</span>
                </h3>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-600 border border-slate-200">
                  {language === 'bn' ? 'শুধুমাত্র পাঠযোগ্য' : 'Read-Only'}
                </span>
              </div>
              <button
                onClick={() => setActiveSubTab('blogs')}
                className="text-xs font-bold text-indigo-600 hover:underline"
              >
                {language === 'bn' ? 'সকল ব্লগ পড়ুন →' : 'Read All Blogs →'}
              </button>
            </div>

            {publishedBlogs.length === 0 ? (
              <div className="p-6 text-center bg-slate-50 rounded-xl border border-slate-200/70 text-xs text-slate-500">
                {language === 'bn'
                  ? 'এখনও কোনো স্কুল ব্লগ পোস্ট প্রকাশিত হয়নি। সুপার অ্যাডমিন ব্লগ প্রকাশ করলে এখানে দেখতে পাবেন।'
                  : 'No school blog posts published yet.'}
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {publishedBlogs.slice(0, 3).map((post) => (
                  <button
                    key={post.id}
                    type="button"
                    onClick={() => setReadingBlogPost(post)}
                    className="text-left bg-slate-50/70 hover:bg-indigo-50/50 rounded-xl border border-slate-200 hover:border-indigo-300 overflow-hidden transition-all flex flex-col justify-between group"
                  >
                    <div>
                      <div className="relative h-32 bg-slate-200 overflow-hidden">
                        <img
                          src={post.coverImage || '/assets/aistudio/school_hero.webp'}
                          alt={post.titleBn || post.titleEn}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                        <span className="absolute top-2 left-2 px-2 py-0.5 rounded-full text-[10px] font-bold bg-white/95 text-indigo-900 shadow-2xs">
                          {language === 'bn' ? post.categoryBn : post.category}
                        </span>
                      </div>
                      <div className="p-3 space-y-1.5">
                        <div className="flex items-center justify-between text-[10px] text-slate-500 font-semibold">
                          <span>{formatDate(post.publishedAt)}</span>
                          <span className="truncate max-w-[110px]">{post.authorName}</span>
                        </div>
                        <h4 className="font-bold text-slate-900 text-xs leading-snug line-clamp-2 group-hover:text-indigo-700">
                          {language === 'bn' ? post.titleBn || post.titleEn : post.titleEn || post.titleBn}
                        </h4>
                        <p className="text-[11px] text-slate-600 line-clamp-2 leading-relaxed">
                          {post.excerpt || post.content}
                        </p>
                      </div>
                    </div>
                    <div className="px-3 pb-3 pt-1 flex items-center text-[11px] font-bold text-indigo-600">
                      <Eye className="w-3.5 h-3.5 mr-1" />
                      <span>{language === 'bn' ? 'সম্পূর্ণ পড়ুন' : 'Read Article'}</span>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* FEATURE 1: TAR ATTENDANCE (হাজিরা রিপোর্ট)                           */}
      {/* ===================================================================== */}
      {activeSubTab === 'attendance' && (
        <div className="space-y-6">
          {/* Attendance Stats Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-center">
            <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs">
              <span className="text-xs text-slate-500 font-bold block">মোট রেকর্ডকৃত দিন</span>
              <span className="text-2xl font-black text-slate-900 mt-1 block">
                {toBnNumber(totalAttendanceDays)} দিন
              </span>
            </div>
            <div className="p-4 bg-white rounded-2xl border border-emerald-200 shadow-xs bg-emerald-50/30">
              <span className="text-xs text-emerald-700 font-bold block">উপস্থিত (Present)</span>
              <span className="text-2xl font-black text-emerald-700 mt-1 block">
                {toBnNumber(presentCount)} দিন
              </span>
            </div>
            <div className="p-4 bg-white rounded-2xl border border-rose-200 shadow-xs bg-rose-50/30">
              <span className="text-xs text-rose-700 font-bold block">অনুপস্থিত (Absent)</span>
              <span className="text-2xl font-black text-rose-700 mt-1 block">
                {toBnNumber(absentCount)} দিন
              </span>
            </div>
            <div className="p-4 bg-white rounded-2xl border border-amber-200 shadow-xs bg-amber-50/30">
              <span className="text-xs text-amber-700 font-bold block">দেরিতে আগমন (Late)</span>
              <span className="text-2xl font-black text-amber-700 mt-1 block">
                {toBnNumber(lateCount)} দিন
              </span>
            </div>
          </div>

          {/* Today's Live Attendance Alert Bar */}
          <div
            className={`p-4 rounded-2xl border flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs ${
              todayRecord?.status === 'Present'
                ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                : todayRecord?.status === 'Absent'
                ? 'bg-rose-50 border-rose-200 text-rose-900'
                : todayRecord?.status === 'Late'
                ? 'bg-amber-50 border-amber-200 text-amber-900'
                : 'bg-amber-50/70 border-amber-200 text-amber-900'
            }`}
          >
            <div className="flex items-center space-x-2.5">
              {todayRecord?.status === 'Present' ? (
                <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
              ) : todayRecord?.status === 'Absent' ? (
                <XCircle className="w-5 h-5 text-rose-600 shrink-0" />
              ) : todayRecord?.status === 'Late' ? (
                <Clock className="w-5 h-5 text-amber-600 shrink-0" />
              ) : (
                <Clock className="w-5 h-5 text-amber-600 shrink-0" />
              )}
              <div>
                <span className="font-extrabold text-sm block">
                  {todayRecord?.status === 'Present'
                    ? `আজকের (${formatDate(todayCalendarDate)}) হাজিরা: উপস্থিত (Present)`
                    : todayRecord?.status === 'Absent'
                    ? `আজকের (${formatDate(todayCalendarDate)}) হাজিরা: অনুপস্থিত (Absent)`
                    : todayRecord?.status === 'Late'
                    ? `আজকের (${formatDate(todayCalendarDate)}) হাজিরা: দেরিতে আগমন (Late)`
                    : `আজ (${formatDate(todayCalendarDate)}) এখনও হাজিরা নিশ্চিত বা স্ক্যান করা হয়নি`}
                </span>
                <span className="text-[11px] opacity-90 block mt-0.5">
                  {todayRecord?.status === 'Present' || todayRecord?.status === 'Late'
                    ? `${todayRecord.status === 'Late' ? 'দেরিতে চেক-ইন' : 'চেক-ইন সময়'}: ${todayRecord.inTime || todayRecord.scanTime || '০৮:২৫ AM'}${todayRecord.outTime ? ` • চেক-আউট: ${todayRecord.outTime}` : ''}${todayRecord.stayDuration ? ` (${todayRecord.stayDuration})` : ''} • পদ্ধতি: ${todayRecord.method === 'face_scan' ? 'AI ফেস স্ক্যানার' : todayRecord.method === 'qr_scanner' ? 'কিউআর কোড স্ক্যানার' : 'শ্রেণিকক্ষ রোল কল'}`
                    : todayRecord?.status === 'Absent'
                    ? 'শ্রেণিকক্ষে অনুপস্থিত হিসেবে নথিভুক্ত করা হয়েছে'
                    : 'শ্রেণি শিক্ষক, ফেস স্ক্যান বা আইডি কার্ড কিউআর স্ক্যানারের মাধ্যমে হাজিরা গৃহীত হলে এখানে রিয়েল-টাইম আপডেট দেখতে পাবেন।'}
                </span>
              </div>
            </div>

            <span
              className={`px-3 py-1 rounded-full text-xs font-black self-start sm:self-auto shrink-0 border ${
                todayRecord?.status === 'Present'
                  ? 'bg-emerald-600 text-white border-emerald-700'
                  : todayRecord?.status === 'Absent'
                  ? 'bg-rose-600 text-white border-rose-700'
                  : todayRecord?.status === 'Late'
                  ? 'bg-amber-600 text-white border-amber-700'
                  : 'bg-amber-100 text-amber-900 border-amber-300'
              }`}
            >
              {todayRecord?.status === 'Present'
                ? 'উপস্থিত ✓'
                : todayRecord?.status === 'Absent'
                ? 'অনুপস্থিত'
                : todayRecord?.status === 'Late'
                ? 'দেরিতে উপস্থিতি'
                : 'হাজিরা বা স্ক্যান বাকি'}
            </span>
          </div>

          {/* Daily Attendance History Table */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="p-4 border-b border-slate-100 flex items-center justify-between">
              <h3 className="font-black text-slate-900 text-sm flex items-center gap-2">
                <CalendarCheck2 className="w-4 h-4 text-emerald-600" />
                <span>দৈনিক হাজিরা লগ ({student.nameBn || student.nameEn} - আইডি: {student.studentId})</span>
              </h3>
              <span className="text-xs font-bold text-slate-500">
                হাজিরা রেটিং: <strong className="text-emerald-600">{toBnNumber(attendanceRate)}%</strong>
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-600 uppercase font-bold text-[10px] border-b border-slate-100">
                  <tr>
                    <th className="py-3 px-4">তারিখ (Date)</th>
                    <th className="py-3 px-4">হাজিরা স্ট্যাটাস</th>
                    <th className="py-3 px-4">চেক-ইন সময়</th>
                    <th className="py-3 px-4">পদ্ধতি (Method)</th>
                    <th className="py-3 px-4">মন্তব্য</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-medium">
                  {studentAttendance.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="py-8 text-center text-slate-400">
                        এখনও কোনো হাজিরার রেকর্ড নেই।
                      </td>
                    </tr>
                  ) : (
                    studentAttendance.map((rec) => (
                      <tr key={rec.id} className="hover:bg-slate-50/80">
                        <td className="py-3 px-4 font-bold text-slate-800">{formatDate(rec.date)}</td>
                        <td className="py-3 px-4">
                          <span
                            className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-black ${
                              rec.status === 'Present'
                                ? 'bg-emerald-100 text-emerald-800'
                                : rec.status === 'Late'
                                ? 'bg-amber-100 text-amber-800'
                                : 'bg-rose-100 text-rose-800'
                            }`}
                          >
                            {rec.status === 'Present' ? 'উপস্থিত' : rec.status === 'Late' ? 'দেরি' : 'অনুপস্থিত'}
                          </span>
                        </td>
                        <td className="py-3 px-4 font-mono text-slate-600">
                          {rec.status === 'Absent' ? (
                            '—'
                          ) : (
                            <div className="space-y-0.5">
                              <div>ইন: {rec.inTime || rec.scanTime || '০৮:২৫ AM'}</div>
                              {rec.outTime && (
                                <div className="text-[10px] text-amber-700 font-semibold">
                                  আউট: {rec.outTime}{rec.stayDuration ? ` (${rec.stayDuration})` : ''}
                                </div>
                              )}
                            </div>
                          )}
                        </td>
                        <td className="py-3 px-4">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                              rec.status === 'Absent'
                                ? 'bg-rose-50 text-rose-700'
                                : rec.method === 'face_scan'
                                ? 'bg-emerald-50 text-emerald-700'
                                : 'bg-indigo-50 text-indigo-700'
                            }`}
                          >
                            {rec.status === 'Absent'
                              ? 'অনুপস্থিত রেকর্ড'
                              : rec.method === 'face_scan'
                              ? 'স্মার্ট AI ফেস স্ক্যান'
                              : rec.method === 'qr_scanner'
                              ? 'স্মার্ট কিউআর কোড স্ক্যান'
                              : 'শ্রেণিকক্ষ হাজিরা'}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-slate-500">
                          {rec.remarks || (rec.status === 'Absent' ? 'অনুপস্থিত' : 'স্বাভাবিক উপস্থিতি')}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* FEATURE 2: HOMEWORK & CLASS REPORT (হোমওয়ার্ক জমা ও সামগ্রিক রিপোর্ট) */}
      {/* ===================================================================== */}
      {activeSubTab === 'homework' && (
        <div className="space-y-6">
          {/* Sub-navigation within Homework: Switch between Assignment List and Class Report & Leaderboard */}
          <div className="flex flex-wrap items-center justify-between gap-3 bg-white p-3.5 rounded-2xl border border-slate-200 shadow-xs">
            <div className="flex items-center space-x-1.5 p-1 bg-slate-100 rounded-xl">
              <button
                type="button"
                onClick={() => setStudentHwViewTab('report')}
                className={`flex items-center space-x-1.5 px-3.5 py-2 rounded-lg text-xs font-bold transition-all ${
                  studentHwViewTab === 'report'
                    ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Award className="w-4 h-4 text-amber-200" />
                <span>১-ক্লিক শ্রেণিভিত্তিক সামারি ও ফার্স্ট র‍্যাংক</span>
              </button>
              <button
                type="button"
                onClick={() => setStudentHwViewTab('assignments')}
                className={`flex items-center space-x-1.5 px-3.5 py-2 rounded-lg text-xs font-bold transition-all ${
                  studentHwViewTab === 'assignments'
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <BookOpen className="w-4 h-4" />
                <span>বাড়ির কাজের তালিকা ও জমা ({toBnNumber(classHomework.length)}টি)</span>
              </button>
            </div>

            {/* Strict Class Isolation Badge: Shows Student's Class is Locked */}
            <div className="flex items-center space-x-2 bg-blue-50/80 px-3 py-1.5 rounded-xl border border-blue-200 text-xs">
              <Lock className="w-3.5 h-3.5 text-blue-700" />
              <span className="text-slate-600 font-semibold">আপনার শ্রেণি:</span>
              <strong className="text-blue-900 font-bold">{student.className}</strong>
              <span className="text-[10px] bg-blue-600 text-white px-1.5 py-0.2 rounded font-bold">লকড (Locked)</span>
            </div>
          </div>

          {/* VIEW A: CLASS HOMEWORK REPORT & 1-CLICK PODIUM (Matching Screenshot) */}
          {studentHwViewTab === 'report' && (
            <div className="space-y-5 animate-in fade-in">
              {/* Filter Bar with Quick Date Range Pills */}
              <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs space-y-3 text-xs">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  {/* Date Range Selector Pills */}
                  <div className="flex flex-wrap items-center gap-1.5">
                    <span className="font-bold text-slate-700 mr-1 flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5 text-blue-600" />
                      <span>তারিখ পরিসীমা:</span>
                    </span>
                    <button
                      type="button"
                      onClick={() => setHwReportDateRange('today')}
                      className={`px-3 py-1.5 rounded-lg font-bold text-xs transition-colors ${
                        hwReportDateRange === 'today'
                          ? 'bg-blue-600 text-white shadow-xs'
                          : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                      }`}
                    >
                      আজ (Today)
                    </button>
                    <button
                      type="button"
                      onClick={() => setHwReportDateRange('this_week')}
                      className={`px-3 py-1.5 rounded-lg font-bold text-xs transition-colors ${
                        hwReportDateRange === 'this_week'
                          ? 'bg-blue-600 text-white shadow-xs'
                          : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                      }`}
                    >
                      এই সপ্তাহ (This Week)
                    </button>
                    <button
                      type="button"
                      onClick={() => setHwReportDateRange('this_month')}
                      className={`px-3 py-1.5 rounded-lg font-bold text-xs transition-colors ${
                        hwReportDateRange === 'this_month'
                          ? 'bg-blue-600 text-white shadow-xs'
                          : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                      }`}
                    >
                      এই মাস (This Month)
                    </button>
                    <button
                      type="button"
                      onClick={() => setHwReportDateRange('this_year')}
                      className={`px-3 py-1.5 rounded-lg font-bold text-xs transition-colors ${
                        hwReportDateRange === 'this_year'
                          ? 'bg-blue-600 text-white shadow-xs'
                          : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                      }`}
                    >
                      এই বছর (This Year)
                    </button>
                    <button
                      type="button"
                      onClick={() => setHwReportDateRange('custom')}
                      className={`px-3 py-1.5 rounded-lg font-bold text-xs transition-colors ${
                        hwReportDateRange === 'custom'
                          ? 'bg-blue-600 text-white shadow-xs'
                          : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                      }`}
                    >
                      কাস্টম তারিখ (From - To)
                    </button>
                  </div>
                </div>

                {/* Sub-row Filters (Strictly Locked to Student's Class) */}
                <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-100">
                  <div className="flex flex-wrap items-center gap-3">
                    {hwReportDateRange === 'custom' && (
                      <div className="flex items-center space-x-1.5 bg-blue-50/50 p-1.5 rounded-lg border border-blue-200">
                        <span className="font-semibold text-slate-600 text-[11px]">শুরু:</span>
                        <input
                          type="date"
                          value={hwReportStartDate}
                          onChange={(e) => setHwReportStartDate(e.target.value)}
                          className="px-2 py-1 border border-slate-200 rounded-md bg-white text-xs"
                        />
                        <span className="font-semibold text-slate-600 text-[11px]">শেষ:</span>
                        <input
                          type="date"
                          value={hwReportEndDate}
                          onChange={(e) => setHwReportEndDate(e.target.value)}
                          className="px-2 py-1 border border-slate-200 rounded-md bg-white text-xs"
                        />
                      </div>
                    )}

                    {/* Strict Class Display: NO DROPDOWN - LOCKED */}
                    <div className="flex items-center space-x-1.5">
                      <span className="font-bold text-slate-700">শ্রেণি:</span>
                      <span className="px-3 py-1.5 bg-blue-50 border border-blue-200 text-blue-900 rounded-lg font-black text-xs inline-flex items-center gap-1 shadow-2xs">
                        <span>{student.className}</span>
                        <span className="text-[10px] text-blue-600 font-bold bg-white px-1.5 py-0.5 rounded border border-blue-200">আপনার শ্রেণি</span>
                      </span>
                    </div>

                    <div className="flex items-center space-x-1.5">
                      <span className="font-bold text-slate-700">শাখা:</span>
                      <select
                        value={hwReportSection}
                        onChange={(e) => setHwReportSection(e.target.value)}
                        className="px-3 py-1.5 border border-slate-200 rounded-lg bg-white font-medium"
                      >
                        <option value="all">সব শাখা (All Sections)</option>
                        <option value="A">Section A</option>
                        <option value="B">Section B</option>
                        <option value="C">Section C</option>
                      </select>
                    </div>

                    <div className="flex items-center space-x-1.5">
                      <span className="font-bold text-slate-700">বিষয়:</span>
                      <select
                        value={hwReportSubject}
                        onChange={(e) => setHwReportSubject(e.target.value)}
                        className="px-3 py-1.5 border border-slate-200 rounded-lg bg-white font-medium max-w-xs truncate"
                      >
                        <option value="all">সব বিষয় (All Subjects)</option>
                        {classHwSubjects.map((sub) => (
                          <option key={sub} value={sub}>{sub}</option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div className="flex items-center space-x-2">
                    <div className="relative">
                      <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
                      <input
                        type="text"
                        placeholder="সহপাঠীর নাম বা রোল..."
                        value={hwReportSearch}
                        onChange={(e) => setHwReportSearch(e.target.value)}
                        className="pl-8 pr-3 py-1.5 border border-slate-200 rounded-lg bg-white text-xs w-44"
                      />
                    </div>
                    <button
                      type="button"
                      onClick={() => window.print()}
                      className="px-3 py-1.5 bg-slate-800 hover:bg-slate-900 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 transition-colors shadow-xs"
                    >
                      <Printer className="w-3.5 h-3.5" />
                      <span>আমার রিপোর্ট প্রিন্ট করুন</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* PRIVACY & PERSONAL REPORT BANNER */}
              <div className="p-5 bg-gradient-to-r from-blue-700 via-indigo-700 to-slate-900 rounded-2xl text-white shadow-md">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div>
                    <div className="flex items-center space-x-2">
                      <GraduationCap className="w-6 h-6 text-amber-300" />
                      <h3 className="text-base font-black tracking-wide">
                        {student.nameBn || student.nameEn}-এর ব্যক্তিগত বাড়ির কাজ ও নম্বর মূল্যায়ন
                      </h3>
                    </div>
                    <p className="text-xs text-blue-100 mt-1">
                      শ্রেণি: <strong>{student.className}</strong> | শাখা: <strong>{student.section}</strong> | রোল: <strong>{student.roll}</strong> • আইডি: <strong>{student.studentId}</strong>
                    </p>
                    <p className="text-[11px] text-emerald-300 mt-1 flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>🔒 ব্যক্তিগত ও সুরক্ষিত পোর্টাল: এখানে শুধুমাত্র আপনার নিজের দেওয়া হোমওয়ার্ক, প্রাপ্ত নম্বর এবং শিক্ষকের মন্তব্য প্রদর্শিত হচ্ছে।</span>
                    </p>
                  </div>

                  <div className="flex items-center gap-2">
                    <div className="bg-white/15 backdrop-blur-xs px-4 py-2.5 rounded-xl border border-white/20 text-center">
                      <span className="text-[10px] font-bold text-amber-200 block uppercase">গড় অর্জিত নম্বর</span>
                      <strong className="text-lg font-black block text-white">
                        {toBnNumber(personalHwReport.percentage)}%
                      </strong>
                      <span className="text-[10px] text-blue-100 font-medium">
                        {personalHwReport.obtainedMarks} / {personalHwReport.totalPossibleMarks} নম্বর
                      </span>
                    </div>
                    <div className="bg-white/15 backdrop-blur-xs px-4 py-2.5 rounded-xl border border-white/20 text-center">
                      <span className="text-[10px] font-bold text-emerald-300 block uppercase">জমার হার</span>
                      <strong className="text-lg font-black block text-white">
                        {toBnNumber(personalHwReport.submissionRate)}%
                      </strong>
                      <span className="text-[10px] text-blue-100 font-medium">
                        {personalHwReport.submittedCount}/{personalHwReport.totalAssigned}টি কাজ
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* 4 PERSONAL KPI CARDS */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                <div className="p-4 bg-white rounded-2xl border border-blue-200 shadow-xs">
                  <span className="text-[11px] text-slate-500 font-bold block">মোট নির্ধারিত বাড়ির কাজ</span>
                  <div className="text-xl font-black text-blue-900 mt-1 flex items-baseline gap-1">
                    <span>{toBnNumber(personalHwReport.totalAssigned)}</span>
                    <span className="text-xs font-normal text-slate-500">টি</span>
                  </div>
                  <span className="text-[10px] text-slate-400 block mt-1">নির্বাচিত সময়কালে</span>
                </div>

                <div className="p-4 bg-white rounded-2xl border border-emerald-200 shadow-xs bg-emerald-50/20">
                  <span className="text-[11px] text-emerald-800 font-bold block">সফলভাবে জমা দিয়েছি</span>
                  <div className="text-xl font-black text-emerald-700 mt-1 flex items-baseline gap-1">
                    <span>{toBnNumber(personalHwReport.submittedCount)}</span>
                    <span className="text-xs font-normal text-slate-500">টি</span>
                  </div>
                  <span className="text-[10px] text-emerald-600 block mt-1">জমার হার: {toBnNumber(personalHwReport.submissionRate)}%</span>
                </div>

                <div className="p-4 bg-white rounded-2xl border border-rose-200 shadow-xs bg-rose-50/20">
                  <span className="text-[11px] text-rose-800 font-bold block">সময় পার / মিসড</span>
                  <div className="text-xl font-black text-rose-700 mt-1 flex items-baseline gap-1">
                    <span>{toBnNumber(personalHwReport.missedCount)}</span>
                    <span className="text-xs font-normal text-slate-500">টি</span>
                  </div>
                  <span className="text-[10px] text-rose-600 block mt-1">
                    {personalHwReport.missedCount === 0 ? 'সব সময়মতো জমা' : 'দেরি হওয়া কাজ'}
                  </span>
                </div>

                <div className="p-4 bg-white rounded-2xl border border-indigo-200 shadow-xs bg-indigo-50/20">
                  <span className="text-[11px] text-indigo-800 font-bold block">মোট প্রাপ্ত নম্বর</span>
                  <div className="text-xl font-black text-indigo-700 mt-1 flex items-baseline gap-1">
                    <span>{toBnNumber(personalHwReport.obtainedMarks)}</span>
                    <span className="text-xs font-normal text-slate-500">/ {toBnNumber(personalHwReport.totalPossibleMarks)}</span>
                  </div>
                  <span className="text-[10px] text-indigo-600 block mt-1">
                    {personalHwReport.percentage >= 80 ? 'চমৎকার মান (A+)' : 'নিয়মিত চর্চা করুন'}
                  </span>
                </div>
              </div>

              {/* SUBJECT-WISE PERSONAL PROGRESS CARDS */}
              {personalHwReport.subjectBreakdown.length > 0 && (
                <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs">
                  <h4 className="text-xs font-black text-slate-900 mb-3 flex items-center gap-1.5">
                    <BookOpen className="w-4 h-4 text-blue-600" />
                    <span>আমার বিষয়ভিত্তিক পারফরম্যান্স অগ্রগতি (Subject-wise Performance)</span>
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                    {personalHwReport.subjectBreakdown.map((sub) => (
                      <div key={sub.subjectName} className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                        <div className="flex items-center justify-between mb-1.5">
                          <strong className="text-xs font-black text-slate-900 truncate">{sub.subjectName}</strong>
                          <span className={`text-[10px] font-black px-2 py-0.5 rounded-full ${
                            sub.percentage >= 80
                              ? 'bg-emerald-100 text-emerald-800'
                              : sub.percentage >= 50
                              ? 'bg-blue-100 text-blue-800'
                              : 'bg-amber-100 text-amber-800'
                          }`}>
                            {toBnNumber(sub.percentage)}%
                          </span>
                        </div>
                        <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden mb-2">
                          <div
                            className={`h-full rounded-full ${
                              sub.percentage >= 80 ? 'bg-emerald-500' : sub.percentage >= 50 ? 'bg-blue-500' : 'bg-amber-500'
                            }`}
                            style={{ width: `${Math.min(100, sub.percentage)}%` }}
                          />
                        </div>
                        <div className="flex items-center justify-between text-[11px] text-slate-500">
                          <span>জমা: {toBnNumber(sub.submittedCount)}/{toBnNumber(sub.assignedCount)}</span>
                          <span className="font-bold text-slate-800">{toBnNumber(sub.obtainedMarks)} / {toBnNumber(sub.totalMarks)} নম্বর</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* STUDENT'S OWN HOMEWORK SUBMISSION HISTORY & MARKS TABLE */}
              <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
                <div className="p-4 border-b border-slate-100 flex items-center justify-between">
                  <h4 className="font-black text-slate-900 text-xs sm:text-sm flex items-center gap-2">
                    <BarChart3 className="w-4 h-4 text-indigo-600" />
                    <span>আমার জমাকৃত বাড়ির কাজ ও শিক্ষকের মূল্যায়ন তালিকা</span>
                  </h4>
                  <span className="text-[11px] font-bold text-slate-500">
                    মোট এন্ট্রি: {toBnNumber(personalHwReport.periodHomework.length)} টি
                  </span>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs whitespace-nowrap">
                    <thead className="bg-slate-50 text-slate-700 border-b border-slate-200 uppercase font-black text-[10px]">
                      <tr>
                        <th className="p-3">অ্যাসাইনমেন্ট শিরোনাম</th>
                        <th className="p-3">বিষয়</th>
                        <th className="p-3 text-center">শেষ তারিখ</th>
                        <th className="p-3 text-center">জমাদানের স্থিতি</th>
                        <th className="p-3 text-center">প্রাপ্ত নম্বর</th>
                        <th className="p-3">শিক্ষক ও এআই মন্তব্য</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {personalHwReport.periodHomework.length === 0 ? (
                        <tr>
                          <td colSpan={6} className="p-8 text-center text-slate-400 text-xs">
                            এই সময়সীমায় কোনো অ্যাসাইনমেন্টের তথ্য পাওয়া যায়নি।
                          </td>
                        </tr>
                      ) : (
                        personalHwReport.periodHomework.map((hw) => {
                          const sub = personalHwReport.submissions.find((s) => s.homeworkId === hw.id);
                          const isSubmitted = !!sub;
                          const hasScore =
                            Boolean(sub) &&
                            (sub!.teacherMarks !== undefined ||
                              (sub!.aiEvaluation !== undefined && !sub!.aiEvaluation.requiresTeacherReview));
                          const obtained = hasScore
                            ? sub!.teacherMarks !== undefined
                              ? sub!.teacherMarks
                              : sub!.aiEvaluation?.suggestedMarks ?? 0
                            : 0;
                          const feedback =
                            sub?.teacherFeedback ||
                            sub?.aiEvaluation?.feedback ||
                            (isSubmitted ? 'মূল্যায়নাধীন' : 'এখনও জমা দেওয়া হয়নি');

                          return (
                            <tr key={hw.id} className="hover:bg-slate-50 transition-colors">
                              <td className="p-3">
                                <strong className="text-slate-900 text-xs block">{hw.title}</strong>
                                <span className="text-[10px] text-slate-400">{hw.description?.slice(0, 45)}...</span>
                              </td>
                              <td className="p-3 font-medium text-slate-700">{hw.subjectName}</td>
                              <td className="p-3 text-center text-slate-600 font-mono text-[11px]">
                                {formatDate(hw.dueDate)}
                              </td>
                              <td className="p-3 text-center">
                                {isSubmitted ? (
                                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
                                    ✓ জমা দেওয়া হয়েছে
                                  </span>
                                ) : (
                                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-800">
                                    বাকি রয়েছে
                                  </span>
                                )}
                              </td>
                              <td className="p-3 text-center font-black">
                                {isSubmitted ? (
                                  hasScore ? (
                                    <span className="text-blue-700">
                                      {toBnNumber(obtained)} / {toBnNumber(hw.fullMarks || 10)}
                                    </span>
                                  ) : (
                                    <span className="text-amber-700 text-[10px] font-bold">রিভিউ অপেক্ষমাণ</span>
                                  )
                                ) : (
                                  <span className="text-slate-400">-</span>
                                )}
                              </td>
                              <td className="p-3 max-w-xs truncate text-[11px] text-slate-600">
                                {feedback}
                              </td>
                            </tr>
                          );
                        })
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* VIEW B: ASSIGNMENTS & HOMEWORK SUBMISSION PORTAL */}
          {studentHwViewTab === 'assignments' && (
            <div className="space-y-4">
              {/* Accounting KPI Cards for Student's Homework */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                <div className="p-3.5 bg-blue-50/70 border border-blue-200 rounded-2xl">
                  <span className="text-[11px] text-blue-700 font-bold block">মোট বাড়ির কাজ</span>
                  <div className="text-xl font-black text-blue-900 mt-1">
                    {toBnNumber(studentHwAccounting.total)} টি
                  </div>
                </div>
                <div className="p-3.5 bg-emerald-50/70 border border-emerald-200 rounded-2xl">
                  <span className="text-[11px] text-emerald-700 font-bold block">সফলভাবে জমা সম্পন্ন</span>
                  <div className="text-xl font-black text-emerald-900 mt-1">
                    {toBnNumber(studentHwAccounting.submitted)} টি
                  </div>
                </div>
                <div className="p-3.5 bg-rose-50/70 border border-rose-200 rounded-2xl">
                  <span className="text-[11px] text-rose-700 font-bold block">সময় উত্তীর্ণ / মিসড (জমা বন্ধ)</span>
                  <div className="text-xl font-black text-rose-900 mt-1">
                    {toBnNumber(studentHwAccounting.expiredCount)} টি
                  </div>
                </div>
                <div className="p-3.5 bg-amber-50/70 border border-amber-200 rounded-2xl">
                  <span className="text-[11px] text-amber-700 font-bold block">চলমান / জমা বাকি</span>
                  <div className="text-xl font-black text-amber-900 mt-1">
                    {toBnNumber(studentHwAccounting.activePendingCount)} টি
                  </div>
                </div>
              </div>

              {/* Blocked Submission Notice Banner if user tries to submit an expired task */}
              {submissionBlockReason && (
                <div className="p-3.5 bg-rose-100 border border-rose-300 text-rose-900 rounded-2xl text-xs font-bold flex items-center justify-between animate-in fade-in">
                  <div className="flex items-center space-x-2">
                    <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                    <span>{submissionBlockReason}</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setSubmissionBlockReason('')}
                    className="p-1 text-rose-700 hover:bg-rose-200 rounded-lg transition-colors"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}

              <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
                <div className="p-4 border-b border-slate-100 flex items-center justify-between">
                  <div>
                    <h3 className="font-black text-slate-900 text-sm flex items-center gap-2">
                      <BookOpen className="w-4 h-4 text-blue-600" />
                      <span>আমার বাড়ির কাজ ও খাতা জমা ({student.className} - শাখা {student.section})</span>
                    </h3>
                    <p className="text-xs text-slate-500 mt-0.5">
                      নির্ধারিত বাড়ির কাজের তালিকা, ছবি আপলোড ও স্বয়ংক্রিয় এআই মূল্যায়ন
                    </p>
                  </div>
                  <span className="px-3 py-1 rounded-full bg-blue-50 text-blue-800 font-bold text-xs">
                    মোট কাজ: {toBnNumber(classHomework.length)} টি
                  </span>
                </div>

                <div className="divide-y divide-slate-100">
                  {classHomework.length === 0 ? (
                    <div className="p-12 text-center text-slate-400 text-xs">
                      আপনার শ্রেণির জন্য কোনো বাড়ির কাজ দেওয়া হয়নি।
                    </div>
                  ) : (
                    classHomework.map((hw) => {
                      const sub = studentSubmissions.find((s) => s.homeworkId === hw.id);
                      const isExpired = !sub && hw.dueDate && todayCalendarDate > hw.dueDate;

                      return (
                        <div key={hw.id} className="p-5 hover:bg-slate-50/50 transition-colors space-y-3">
                          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                            <div className="space-y-1">
                              <div className="flex items-center space-x-2">
                                <span className="px-2 py-0.5 rounded bg-blue-100 text-blue-800 font-bold text-[10px]">
                                  {hw.subjectName}
                                </span>
                                <h4 className="font-extrabold text-slate-900 text-sm">{hw.title}</h4>
                              </div>
                              <p className="text-slate-600 text-xs">{hw.description}</p>
                              <div className="flex items-center space-x-3 text-[11px] text-slate-500 pt-0.5 flex-wrap">
                                <span>শিক্ষক: <strong>{hw.teacherName}</strong></span>
                                <span>•</span>
                                <span>পূর্ণমান: <strong>{hw.fullMarks || 10} নম্বর</strong></span>
                                <span>•</span>
                                <span className={isExpired ? 'text-rose-600 font-bold' : ''}>
                                  জমার শেষ তারিখ: <strong>{formatDate(hw.dueDate)}</strong>
                                  {isExpired && ' (সময় উত্তীর্ণ)'}
                                </span>
                              </div>
                            </div>

                            <div>
                              {sub ? (
                                <div className="text-right">
                                  <span className="px-3 py-1 rounded-full text-xs font-black bg-emerald-100 text-emerald-800 inline-flex items-center gap-1">
                                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                                    <span>জমা দেওয়া হয়েছে</span>
                                  </span>
                                  <div className="text-[11px] text-slate-500 mt-1">
                                    তারিখ: {sub.submissionDate}
                                  </div>
                                </div>
                              ) : isExpired ? (
                                <div className="text-right">
                                  <span className="flex items-center space-x-1.5 px-3.5 py-2 bg-rose-50 text-rose-700 border border-rose-200 rounded-xl text-xs font-bold shadow-2xs">
                                    <Lock className="w-3.5 h-3.5 text-rose-500" />
                                    <span>জমার সময় শেষ (Expired)</span>
                                  </span>
                                  <span className="text-[10px] text-rose-600 block mt-1 font-semibold">
                                    ডেডলাইন পার হওয়ায় জমা বন্ধ
                                  </span>
                                </div>
                              ) : (
                                <button
                                  type="button"
                                  onClick={() => handleOpenSubmit(hw)}
                                  className="flex items-center space-x-1.5 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-xs transition-all"
                                >
                                  <Upload className="w-3.5 h-3.5" />
                                  <span>উত্তর জমা দিন (Submit)</span>
                                </button>
                              )}
                            </div>
                          </div>

                          {/* Overdue/Expired Banner for this homework */}
                          {isExpired && (
                            <div className="p-3 bg-rose-50/80 border border-rose-200 rounded-xl text-xs text-rose-800 flex items-center space-x-2">
                              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                              <span>
                                <strong>সময় উত্তীর্ণ:</strong> এই বাড়ির কাজের নির্ধারিত জমার শেষ তারিখ ({formatDate(hw.dueDate)}) পার হয়ে গেছে। নীতিমালা অনুযায়ী নির্দিষ্ট সময় পার হয়ে গেলে আর খাতা জমা দেওয়া যায় না।
                              </span>
                            </div>
                          )}

                        {/* AI Evaluation & Teacher Feedback Details */}
                        {sub && (
                          <div className="p-3.5 bg-indigo-50/70 border border-indigo-200 rounded-xl space-y-2 text-xs">
                            <div className="flex flex-wrap items-center justify-between gap-2">
                              <span className="font-extrabold text-indigo-950 flex items-center gap-1.5">
                                <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
                                <span>মূল্যায়ন ও প্রাপ্ত নম্বর:</span>
                              </span>
                              <span className="px-2.5 py-0.5 rounded-full text-xs font-black bg-indigo-600 text-white">
                                {sub.teacherMarks !== undefined || (sub.aiEvaluation && !sub.aiEvaluation.requiresTeacherReview)
                                  ? `প্রাপ্ত নম্বর: ${toBnNumber(sub.teacherMarks !== undefined ? sub.teacherMarks : sub.aiEvaluation?.suggestedMarks ?? 0)} / ${toBnNumber(hw.fullMarks || 10)}`
                                  : sub.status === 'review_required'
                                  ? 'শিক্ষকের রিভিউ অপেক্ষমাণ'
                                  : 'এআই মূল্যায়ন চলছে...'}
                              </span>
                            </div>

                            {sub.aiEvaluation?.feedback && (
                              <p className="text-indigo-900 font-medium">
                                <strong>এআই ফিডব্যাক:</strong> {sub.aiEvaluation.feedback}
                              </p>
                            )}

                            {sub.teacherFeedback && (
                              <p className="text-slate-800 font-medium pt-1 border-t border-indigo-100">
                                <strong>শিক্ষকের মন্তব্য:</strong> {sub.teacherFeedback}
                              </p>
                            )}

                            {sub.imageUrls && sub.imageUrls.length > 0 && (
                              <div className="pt-2 flex items-center space-x-2">
                                <span className="text-[11px] text-slate-600 font-bold">জমা দেওয়া খাতার ছবি:</span>
                                <div className="flex space-x-1.5">
                                  {sub.imageUrls.map((url, i) => (
                                    <img key={i} src={url} alt="Submission" className="w-10 h-10 object-cover rounded-lg border border-indigo-300" />
                                  ))}
                                </div>
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          </div>
        )}
        </div>
      )}

      {/* ===================================================================== */}
      {/* FEATURE 3: CLASS ROUTINE (ক্লাস রুটিন)                                */}
      {/* ===================================================================== */}
      {activeSubTab === 'routine' && (
        <div className="space-y-6">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-5">
            <div className="flex items-center justify-between pb-4 mb-4 border-b border-slate-100">
              <div>
                <h3 className="font-black text-slate-900 text-base flex items-center gap-2">
                  <CalendarDays className="w-5 h-5 text-indigo-600" />
                  <span>সাপ্তাহিক ক্লাস রুটিন ({student.className} - শাখা {student.section} - {student.shift} Shift)</span>
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  আপনার নির্দিষ্ট শ্রেণি ও শাখার অনুমোদিত ক্লাস সময়সূচি
                </p>
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <SaturdayOffToggle compact={true} />
                <span className="px-3 py-1 bg-indigo-50 text-indigo-800 rounded-lg text-xs font-bold">
                  সেশন ২০২৬
                </span>
              </div>
            </div>

            <div className="space-y-5">
              {routineDays.map((day) => {
                const isSat = day === 'Saturday';
                const dayPeriods = studentRoutines.filter((r) => r.day === day);

                return (
                  <div key={day} className={`border rounded-xl overflow-hidden ${isSat && isSaturdayOff ? 'border-amber-300 bg-amber-50/20' : 'border-slate-200'}`}>
                    <div className={`px-4 py-2 text-xs font-black flex items-center justify-between ${isSat && isSaturdayOff ? 'bg-amber-100 text-amber-900' : 'bg-slate-100 text-slate-800'}`}>
                      <div className="flex items-center space-x-2">
                        <span>{dayNamesBn[day]} ({day})</span>
                        {isSat && (
                          <span className={`px-2 py-0.5 rounded text-[10px] font-extrabold ${isSaturdayOff ? 'bg-amber-200 text-amber-900' : 'bg-emerald-200 text-emerald-900'}`}>
                            {isSaturdayOff ? '🏖️ সাপ্তাহিক ছুটি (School Weekend)' : '📖 নিয়মিত ক্লাস (Madrasha Open)'}
                          </span>
                        )}
                      </div>
                      <span className="text-slate-500 font-normal">
                        {isSat && isSaturdayOff ? 'ছুটি (Off-day)' : `${toBnNumber(dayPeriods.length)} টি পিরিয়ড`}
                      </span>
                    </div>

                    <div className="p-3 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
                      {isSat && isSaturdayOff ? (
                        <div className="col-span-full py-5 text-center text-amber-800 text-xs font-semibold bg-amber-50/50 rounded-lg border border-amber-200/60">
                          🏖️ সাধারণ স্কুলে শনিবার সাপ্তাহিক ছুটি। মাদরাসা বা শনিবার ক্লাস চালু রাখতে ওপরের ১-ক্লিক বাটনে ক্লিক করুন।
                        </div>
                      ) : dayPeriods.length === 0 ? (
                        <div className="col-span-full py-3 text-center text-slate-400 text-xs">
                          এই দিনে কোনো নির্ধারিত ক্লাস নেই।
                        </div>
                      ) : (
                        dayPeriods.map((p) => (
                          <div
                            key={p.id}
                            className="p-3 bg-slate-50 rounded-lg border border-slate-200 hover:border-indigo-300 transition-colors"
                          >
                            <span className="text-[10px] font-bold text-indigo-600 block uppercase">
                              পিরিয়ড {toBnNumber(p.periodNumber)} ({p.startTime} - {p.endTime})
                            </span>
                            <h4 className="font-black text-slate-900 text-xs mt-1">{p.subjectName}</h4>
                            <p className="text-[11px] text-slate-600 font-medium">{p.teacherName}</p>
                            <span className="text-[10px] text-slate-400 block mt-1">কক্ষ: {p.roomNo}</span>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* FEATURE 4: PUBLISHED EXAM ROUTINE & PERSONAL SEAT PLAN                */}
      {/* ===================================================================== */}
      {activeSubTab === 'exam_routine' && (
        <div className="space-y-6">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="font-black text-slate-900 text-base flex items-center gap-2">
                <Calendar className="w-5 h-5 text-indigo-600" />
                <span>
                  {language === 'bn'
                    ? `প্রকাশিত পরীক্ষার রুটিন ও ব্যক্তিগত আসন বিন্যাস (${student.className})`
                    : `Published Exam Routine & Personal Seat Plan (${student.className})`}
                </span>
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                {language === 'bn'
                  ? `${student.nameBn || student.nameEn} • আইডি: ${student.studentId} • শাখা: ${student.section} • রোল: ${student.roll}`
                  : `${student.nameEn || student.nameBn} • ID: ${student.studentId} • Section: ${student.section} • Roll: ${student.roll}`}
              </p>
            </div>
            {(studentPublishedExamRoutineGroups.length > 0 || studentPublishedSeatPlans.length > 0) && (
              <button
                type="button"
                onClick={() => window.print()}
                className="flex items-center space-x-1.5 px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold text-xs shadow-xs transition-colors self-start sm:self-auto print:hidden"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>{language === 'bn' ? 'রুটিন ও আসন প্রিন্ট করুন' : 'Print Routine & Seat'}</span>
              </button>
            )}
          </div>

          {studentPublishedExamRoutineGroups.length === 0 && studentPublishedSeatPlans.length === 0 ? (
            <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-xs text-center space-y-3">
              <div className="w-14 h-14 mx-auto rounded-2xl bg-amber-50 border border-amber-200 flex items-center justify-center text-amber-600">
                <Lock className="w-7 h-7" />
              </div>
              <h3 className="text-base font-black text-slate-900">
                {language === 'bn'
                  ? 'পরীক্ষার রুটিন ও আসন এখনো প্রকাশিত হয়নি (Not Published Yet)'
                  : 'Exam Routine & Seat Plan Not Published Yet'}
              </h3>
              <p className="text-xs text-slate-600 max-w-md mx-auto leading-relaxed">
                {language === 'bn'
                  ? 'সুপার অ্যাডমিন কর্তৃক পরীক্ষার রুটিন বা আসন বিন্যাস আনুষ্ঠানিকভাবে অনুমোদন ও প্রকাশ (Publish) না করা পর্যন্ত এখানে প্রদর্শিত হবে না। প্রকাশ হলে এখানে আপনার শ্রেণির রুটিন ও শুধুমাত্র আপনার নিজের আসন বিন্যাস দেখতে পারবেন।'
                  : 'Once the Super Admin approves and publishes the exam routine or seat plan, your class schedule and your personal seat allocation will appear here.'}
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
              {/* Left: Published Exam Routine(s) for Student's Class */}
              <div className="lg:col-span-7 space-y-4">
                {studentPublishedExamRoutineGroups.length === 0 ? (
                  <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs text-center space-y-2">
                    <Calendar className="w-8 h-8 text-slate-300 mx-auto" />
                    <h4 className="text-sm font-black text-slate-800">
                      {language === 'bn' ? 'পরীক্ষার রুটিন এখনো প্রকাশিত হয়নি' : 'Exam Routine Not Published Yet'}
                    </h4>
                    <p className="text-xs text-slate-500">
                      {language === 'bn'
                        ? 'রুটিন প্রকাশিত হলে তারিখ, সময় ও বিষয়সহ এখানে তালিকা দেখতে পাবেন।'
                        : 'Subject dates and timings will appear here once published.'}
                    </p>
                  </div>
                ) : (
                  studentPublishedExamRoutineGroups.map((group) => (
                    <div
                      key={group.examId}
                      className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden"
                    >
                      <div className="p-4 bg-slate-50 border-b border-slate-100 flex flex-wrap items-center justify-between gap-2">
                        <div>
                          <h4 className="font-black text-slate-900 text-sm flex items-center gap-2">
                            <Calendar className="w-4 h-4 text-indigo-600" />
                            <span>
                              {group.examTitle} ({student.className})
                            </span>
                          </h4>
                          <p className="text-[11px] text-slate-500 mt-0.5">
                            {group.session
                              ? `${language === 'bn' ? 'শিক্ষাবর্ষ' : 'Session'}: ${group.session} • `
                              : ''}
                            {toBnNumber(group.items.length)} {language === 'bn' ? 'টি বিষয়' : 'subjects'}
                          </p>
                        </div>
                        <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                          {language === 'bn' ? 'অনুমোদিত ও প্রকাশিত' : 'Approved & Published'}
                        </span>
                      </div>

                      <div className="divide-y divide-slate-100">
                        {group.items.map((er) => (
                          <div
                            key={er.id}
                            className="px-4 py-3 flex items-center justify-between gap-3 text-xs hover:bg-slate-50/70 transition-colors"
                          >
                            <div className="min-w-0">
                              <div className="flex flex-wrap items-center gap-1.5">
                                <span className="font-bold text-slate-900">
                                  {er.subjectNameBn || er.subjectNameEn}
                                </span>
                                {er.subjectCode && (
                                  <span className="px-1.5 py-0.5 rounded bg-slate-100 text-slate-600 font-mono text-[10px] font-bold">
                                    {er.subjectCode}
                                  </span>
                                )}
                                {er.group && er.group !== 'General' && (
                                  <span className="px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-200 text-[10px] font-bold">
                                    {formatGroupName(er.group, language)}
                                  </span>
                                )}
                              </div>
                              <div className="text-[11px] text-slate-500 mt-0.5">
                                {language === 'bn' ? 'কক্ষ:' : 'Room:'} {er.roomNo || (language === 'bn' ? 'নির্ধারিত আসন কক্ষ' : 'Assigned Hall')}
                              </div>
                            </div>
                            <div className="text-right font-mono text-[11px] shrink-0">
                              <div className="font-bold text-indigo-700">
                                {er.examDate}
                                {er.dayOfWeek ? ` (${er.dayOfWeek})` : ''}
                              </div>
                              <div className="text-slate-500">
                                {er.startTime} - {er.endTime}
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))
                )}
              </div>

              {/* Right: Strictly Personal Seat Plan Card(s) (ONLY Current Student) */}
              <div className="lg:col-span-5 space-y-4">
                {studentPublishedSeatPlans.length === 0 ? (
                  <div className="bg-slate-50 p-6 rounded-2xl border border-slate-200 text-center space-y-2.5">
                    <div className="w-11 h-11 mx-auto rounded-xl bg-amber-50 border border-amber-200 flex items-center justify-center text-amber-600">
                      <Building className="w-5 h-5" />
                    </div>
                    <h4 className="text-sm font-black text-slate-900">
                      {language === 'bn' ? 'আপনার আসন বিন্যাস এখনো প্রকাশিত হয়নি' : 'Your Seat Plan Not Published Yet'}
                    </h4>
                    <p className="text-xs text-slate-600 leading-relaxed">
                      {language === 'bn'
                        ? 'সুপার অ্যাডমিন আসন বিন্যাস প্রকাশ করলে শুধুমাত্র আপনার নির্ধারিত কক্ষ, বেঞ্চ এবং আসন অবস্থান এখানে দেখতে পাবেন।'
                        : 'Once published, only your personal room, bench, and seat assignment will appear here.'}
                    </p>
                  </div>
                ) : (
                  studentPublishedSeatPlans.map((seatInfo) => (
                    <div
                      key={`${seatInfo.examId}_${seatInfo.assignment.id}`}
                      className="bg-gradient-to-br from-indigo-900 to-blue-900 text-white rounded-2xl border border-indigo-700 p-5 shadow-sm flex flex-col justify-between space-y-4"
                    >
                      <div className="space-y-2">
                        <div className="flex items-center justify-between gap-2">
                          <span className="text-[11px] font-bold text-amber-300 uppercase tracking-wide inline-flex items-center gap-1">
                            <ShieldCheck className="w-3.5 h-3.5 text-amber-300" />
                            <span>
                              {language === 'bn' ? 'শুধুমাত্র আপনার আসন বিন্যাস' : 'Your Personal Seat Plan'}
                            </span>
                          </span>
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/25 text-emerald-200 border border-emerald-400/30">
                            {language === 'bn' ? 'প্রকাশিত' : 'Published'}
                          </span>
                        </div>

                        <h4 className="text-base font-black text-white">
                          {seatInfo.examTitle}
                        </h4>

                        <div className="p-2.5 rounded-xl bg-white/10 border border-white/15 text-xs space-y-1">
                          <div className="font-bold text-white">
                            {student.nameBn || student.nameEn}
                          </div>
                          <div className="text-[11px] text-indigo-100 flex flex-wrap gap-x-3 gap-y-0.5">
                            <span>আইডি: {student.studentId}</span>
                            <span>শ্রেণি: {student.className} ({student.section})</span>
                            <span>রোল: {student.roll}</span>
                          </div>
                        </div>

                        <div className="text-xs text-indigo-100 space-y-1 pt-1">
                          <p>
                            {language === 'bn' ? 'কক্ষ নম্বর:' : 'Room No:'}{' '}
                            <strong className="text-white">
                              {seatInfo.room?.roomNo || seatInfo.assignment.roomNo}
                            </strong>
                            {seatInfo.room?.building ? ` (${seatInfo.room.building})` : ''}
                          </p>
                          {seatInfo.room?.invigilatorName && (
                            <p className="text-[11px] text-indigo-200">
                              {language === 'bn' ? 'কক্ষ পরিদর্শক:' : 'Invigilator:'}{' '}
                              <span className="text-white font-semibold">{seatInfo.room.invigilatorName}</span>
                            </p>
                          )}
                        </div>
                      </div>

                      <div className="pt-3 border-t border-white/15 grid grid-cols-3 gap-2 text-center text-xs">
                        <div className="p-2.5 rounded-xl bg-white/10">
                          <span className="text-[10px] text-indigo-200 block">
                            {language === 'bn' ? 'কলাম / সারি' : 'Column'}
                          </span>
                          <strong className="font-black text-sm text-white">
                            {toBnNumber(seatInfo.assignment.columnIndex)}
                          </strong>
                        </div>
                        <div className="p-2.5 rounded-xl bg-white/10">
                          <span className="text-[10px] text-indigo-200 block">
                            {language === 'bn' ? 'বেঞ্চ নম্বর' : 'Bench No'}
                          </span>
                          <strong className="font-black text-sm text-white">
                            {toBnNumber(seatInfo.assignment.benchNumber)}
                          </strong>
                        </div>
                        <div className="p-2.5 rounded-xl bg-white/10">
                          <span className="text-[10px] text-indigo-200 block">
                            {language === 'bn' ? 'আসন অবস্থান' : 'Seat'}
                          </span>
                          <strong className="font-black text-sm text-amber-300">
                            {seatInfo.assignment.seatLabel || toBnNumber(seatInfo.assignment.seatPosition)}
                          </strong>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>
      )}

      {/* ===================================================================== */}
      {/* FEATURE 5: NOTICE BOARD (নোটিশ বোর্ড)                                  */}
      {/* ===================================================================== */}
      {activeSubTab === 'notices' && (
        <div className="space-y-6">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="p-4 border-b border-slate-100 flex items-center justify-between">
              <h3 className="font-black text-slate-900 text-sm flex items-center gap-2">
                <Bell className="w-4 h-4 text-amber-500" />
                <span>আমার নোটিশ বোর্ড ({student.className})</span>
              </h3>
              <span className="text-xs text-slate-500">
                সর্বশেষ নোটিশ সংখ্যা: {toBnNumber(studentNotices.length)} টি
              </span>
            </div>

            <div className="divide-y divide-slate-100">
              {studentNotices.length === 0 ? (
                <div className="p-12 text-center text-slate-400 text-xs">
                  বর্তমানে কোনো নতুন নোটিশ প্রকাশিত হয়নি।
                </div>
              ) : (
                studentNotices.map((n) => (
                  <div key={n.id} className="p-5 hover:bg-slate-50/60 transition-colors space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800 uppercase">
                          {n.category || 'General'}
                        </span>
                        <h4 className="font-extrabold text-slate-900 text-sm">{n.title}</h4>
                      </div>
                      <span className="text-xs text-slate-500 font-semibold">{formatDate(n.date)}</span>
                    </div>
                    <p className="text-xs text-slate-700 leading-relaxed">{n.content}</p>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* FEATURE 6: EXAM MARKSHEET & CLASS MERIT LIST (মার্কশিট ও মেধা তালিকা)  */}
      {/* ===================================================================== */}
      {activeSubTab === 'exams' && (
        <div className="space-y-6">
          {publishedExams.length === 0 || !currentExam ? (
          <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-xs text-center space-y-3">
            <div className="w-14 h-14 mx-auto rounded-2xl bg-amber-50 border border-amber-200 flex items-center justify-center text-amber-600">
              <Lock className="w-7 h-7" />
            </div>
            <h3 className="text-base font-black text-slate-900">
              ফলাফল এখনো প্রকাশিত হয়নি (Result Not Published Yet)
            </h3>
            <p className="text-xs text-slate-600 max-w-md mx-auto leading-relaxed">
              সুপার অ্যাডমিন কর্তৃক পরীক্ষার ফলাফল আনুষ্ঠানিকভাবে অনুমোদন ও প্রকাশ (Publish) না করা পর্যন্ত খসড়া ফলাফল শিক্ষার্থী পোর্টালে প্রদর্শিত হবে না। ফলাফল প্রকাশ হলে এখান থেকে মার্কশিট ও মেধা তালিকা দেখতে ও প্রিন্ট করতে পারবেন।
            </p>
          </div>
        ) : (
        <div className="space-y-6">
          {/* Term Selector Bar */}
          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="flex items-center space-x-2">
              <span className="font-bold text-slate-700">প্রকাশিত পরীক্ষা নির্বাচন করুন:</span>
              <select
                value={currentExam.id}
                onChange={(e) => setSelectedExamId(e.target.value)}
                className="px-3 py-1.5 border border-slate-200 rounded-lg bg-white font-bold text-slate-900"
              >
                {publishedExams.map((ex) => (
                  <option key={ex.id} value={ex.id}>
                    {ex.nameBn || ex.nameEn} ({ex.session})
                  </option>
                ))}
              </select>
            </div>

            <div className="flex items-center space-x-2">
              <button
                onClick={() => window.print()}
                className="flex items-center space-x-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-bold text-xs shadow-xs transition-colors"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>মার্কশিট প্রিন্ট করুন</span>
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Left: Student Marksheet Table (7 Cols) */}
            <div className="lg:col-span-7 bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
              <div className="p-4 bg-slate-50 border-b border-slate-100 flex items-center justify-between">
                <div>
                  <h4 className="font-black text-slate-900 text-sm">
                    {student.nameBn || student.nameEn} - {currentExam?.nameBn || currentExam?.nameEn || 'পরীক্ষার গ্রেডশিট'}
                  </h4>
                  <p className="text-[11px] text-slate-500">
                    রোল: {student.roll} • আইডি: {student.studentId} • শ্রেণি: {student.className}
                  </p>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-slate-500 block uppercase font-bold">শ্রেণি মেধা স্থান</span>
                  <span className="px-2.5 py-0.5 rounded-full text-xs font-black bg-amber-400 text-blue-950">
                    {currentStudentRank !== null ? `${toBnNumber(currentStudentRank)}ম স্থান` : '—'}
                  </span>
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full min-w-[520px] text-left text-xs">
                  <thead className="bg-slate-100 text-slate-700 uppercase font-bold text-[10px] border-b border-slate-200">
                    <tr>
                      <th className="py-2.5 px-3">বিষয় (Subject)</th>
                      <th className="py-2.5 px-2.5 text-center whitespace-nowrap">লিখিত</th>
                      <th className="py-2.5 px-2.5 text-center whitespace-nowrap">নৈর্ব্যক্তিক (MCQ)</th>
                      <th className="py-2.5 px-2.5 text-center whitespace-nowrap">ব্যবহারিক</th>
                      <th className="py-2.5 px-2.5 text-center whitespace-nowrap">মোট</th>
                      <th className="py-2.5 px-2.5 text-center whitespace-nowrap">গ্রেড</th>
                      <th className="py-2.5 px-3 text-center whitespace-nowrap">জিপিএ (GPA)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-medium">
                    {studentMarks.length === 0 ? (
                      <tr>
                        <td colSpan={7} className="py-8 text-center text-slate-400">
                          এই পরীক্ষার জন্য এখনও মার্কস এন্ট্রি করা হয়নি।
                        </td>
                      </tr>
                    ) : (
                      studentMarks.map((m) => {
                        const matchedSub = findSubjectForMark(allSubjects, m, student.className);
                        const breakdown = getMarksheetRowBreakdown(m, matchedSub);
                        return (
                          <tr key={m.id} className="hover:bg-slate-50">
                            <td className="py-2.5 px-3 font-bold text-slate-900">
                              {matchedSub?.nameBn || m.subjectName}
                            </td>
                            <td className="py-2.5 px-2.5 text-center text-slate-700">
                              {breakdown.hasWritten ? toBnNumber(breakdown.written) : '—'}
                            </td>
                            <td className="py-2.5 px-2.5 text-center text-slate-700">
                              {breakdown.hasMcq ? toBnNumber(breakdown.mcq) : '—'}
                            </td>
                            <td className="py-2.5 px-2.5 text-center text-slate-700">
                              {breakdown.hasPractical ? toBnNumber(breakdown.practical) : '—'}
                            </td>
                            <td className="py-2.5 px-2.5 text-center font-bold text-slate-900">
                              {toBnNumber(breakdown.total)}
                            </td>
                            <td className="py-2.5 px-2.5 text-center">
                              <span
                                className={`px-2 py-0.5 rounded text-[10px] font-black ${
                                  m.grade === 'A+' || m.grade === 'A'
                                    ? 'bg-emerald-100 text-emerald-800'
                                    : m.grade === 'F'
                                    ? 'bg-rose-100 text-rose-800'
                                    : 'bg-blue-100 text-blue-800'
                                }`}
                              >
                                {m.grade}
                              </span>
                            </td>
                            <td className="py-2.5 px-3 text-center font-mono font-bold text-indigo-700">
                              {m.gpa.toFixed(2)}
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                  {studentMarks.length > 0 && (() => {
                    const hasFail = studentMarks.some((m) => m.grade === 'F');
                    const gpaRes = calculateTotalGPA(studentMarks.map((m) => m.gpa), hasFail);
                    const totalScore = studentMarks.reduce((sum, m) => sum + getMarksheetRowBreakdown(m, findSubjectForMark(allSubjects, m, student.className)).total, 0);
                    const isPassed = !hasFail && gpaRes.status === 'PASSED';

                    return (
                      <tfoot className="bg-slate-50 font-black text-slate-900 border-t-2 border-slate-200 text-xs">
                        <tr>
                          <td className="py-3 px-3">সর্বমোট / সামগ্রিক ফলাফল:</td>
                          <td colSpan={3} className="py-3 px-3 text-center text-slate-600">
                            {toBnNumber(studentMarks.length)} টি বিষয়
                          </td>
                          <td className="py-3 px-2.5 text-center text-emerald-700 font-black text-sm">
                            {toBnNumber(totalScore)}
                          </td>
                          <td className="py-3 px-2.5 text-center">
                            <span className={`px-2 py-0.5 rounded text-[10px] font-black ${
                              isPassed ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                            }`}>
                              {isPassed ? `${gpaRes.overallGrade} (উত্তীর্ণ)` : `${gpaRes.overallGrade} (অনুত্তীর্ণ)`}
                            </span>
                          </td>
                          <td className={`py-3 px-3 text-center font-mono font-black text-sm ${isPassed ? 'text-indigo-700' : 'text-rose-600'}`}>
                            {gpaRes.totalGPA.toFixed(2)}
                          </td>
                        </tr>
                      </tfoot>
                    );
                  })()}
                </table>
              </div>
            </div>

            {/* Right: Student's Personal Exam Performance & Grade Analytics (5 Cols) */}
            <div className="lg:col-span-5 bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden flex flex-col">
              <div className="p-4 bg-gradient-to-r from-blue-900 to-indigo-900 text-white flex items-center justify-between">
                <div>
                  <h4 className="font-black text-white text-sm flex items-center gap-1.5">
                    <Award className="w-4 h-4 text-amber-300" />
                    <span>আমার ফলাফল ও গ্রেড বিশ্লেষণ (My Performance)</span>
                  </h4>
                  <p className="text-[11px] text-indigo-200 mt-0.5">
                    {student.nameBn || student.nameEn} • রোল: {student.roll} ({student.className})
                  </p>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-amber-300 block font-bold uppercase">আমার মেধা স্থান</span>
                  <span className="px-2.5 py-0.5 rounded-full text-xs font-black bg-amber-400 text-slate-900 inline-block shadow-xs">
                    {currentStudentRank !== null ? `${toBnNumber(currentStudentRank)}ম স্থান` : '—'}
                  </span>
                </div>
              </div>

              {/* Privacy Notice */}
              <div className="px-3.5 py-2 bg-emerald-50 border-b border-emerald-100 flex items-center gap-1.5 text-[11px] text-emerald-800 font-medium">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                <span>🔒 প্রাতিষ্ঠানিক গোপনীয়তা রক্ষা: প্রতিটি শিক্ষার্থী শুধুমাত্র তার নিজের পরীক্ষার গ্রেড ও ফলাফল দেখতে পারে।</span>
              </div>

              {/* Subject Breakdown & Visual Progress */}
              <div className="p-4 space-y-3.5 flex-1 overflow-y-auto max-h-[380px]">
                <h5 className="text-xs font-black text-slate-900 flex items-center gap-1.5">
                  <BarChart3 className="w-3.5 h-3.5 text-blue-600" />
                  <span>বিষয়ভিত্তিক নম্বর ও গ্রেড অর্জনের হার:</span>
                </h5>

                {studentMarks.length === 0 ? (
                  <div className="py-8 text-center text-slate-400 text-xs">
                    এখনও কোনো বিষয়ের নম্বর এন্ট্রি সম্পন্ন হয়নি।
                  </div>
                ) : (
                  studentMarks.map((m) => {
                    const matchedSub = findSubjectForMark(allSubjects, m, student.className);
                    const breakdown = getMarksheetRowBreakdown(m, matchedSub);
                    const pct = breakdown.fullMarks > 0
                      ? Math.min(100, Math.round((breakdown.total / breakdown.fullMarks) * 100))
                      : 0;
                    return (
                      <div key={m.id} className="p-3 bg-slate-50 rounded-xl border border-slate-200/80 space-y-1.5">
                        <div className="flex items-center justify-between">
                          <strong className="text-xs font-black text-slate-900">
                            {matchedSub?.nameBn || m.subjectName}
                          </strong>
                          <div className="flex items-center space-x-1.5">
                            <span className={`px-2 py-0.5 rounded text-[10px] font-black ${
                              m.grade === 'A+' || m.grade === 'A'
                                ? 'bg-emerald-100 text-emerald-800'
                                : m.grade === 'F'
                                ? 'bg-rose-100 text-rose-800'
                                : 'bg-blue-100 text-blue-800'
                            }`}>
                              {m.grade} (GPA {m.gpa.toFixed(2)})
                            </span>
                            <span className="text-xs font-black text-slate-900">
                              {toBnNumber(breakdown.total)} <span className="text-[10px] text-slate-400 font-normal">/ {toBnNumber(breakdown.fullMarks)}</span>
                            </span>
                          </div>
                        </div>

                        {/* Progress Bar */}
                        <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                          <div
                            className={`h-full rounded-full transition-all duration-500 ${
                              m.grade === 'A+'
                                ? 'bg-emerald-500'
                                : m.grade === 'A'
                                ? 'bg-teal-500'
                                : m.grade === 'F'
                                ? 'bg-rose-500'
                                : 'bg-blue-500'
                            }`}
                            style={{ width: `${pct}%` }}
                          />
                        </div>

                        <div className="flex items-center justify-between gap-2 text-[10px] text-slate-500 flex-wrap">
                          <span>
                            {breakdown.hasWritten ? `লিখিত: ${toBnNumber(breakdown.written)}` : ''}
                            {breakdown.hasMcq ? `${breakdown.hasWritten ? ' • ' : ''}নৈর্ব্যক্তিক: ${toBnNumber(breakdown.mcq)}` : ''}
                            {breakdown.hasPractical ? `${(breakdown.hasWritten || breakdown.hasMcq) ? ' • ' : ''}ব্যবহারিক: ${toBnNumber(breakdown.practical)}` : ''}
                          </span>
                          <span className="font-bold text-slate-700">অর্জিত: {toBnNumber(pct)}%</span>
                        </div>
                      </div>
                    );
                  })
                )}

                {/* Overall Performance Card */}
                {studentMarks.length > 0 && (() => {
                  const hasFail = studentMarks.some((m) => m.grade === 'F');
                  const gpaRes = calculateTotalGPA(studentMarks.map((m) => m.gpa), hasFail);
                  const isPassed = !hasFail && gpaRes.status === 'PASSED';

                  return (
                    <div className="p-3 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl border border-blue-200 text-xs space-y-1">
                      <div className="flex items-center justify-between font-black text-slate-900">
                        <span>সামগ্রিক শিক্ষাবর্ষ ফলাফল:</span>
                        <span className={isPassed ? 'text-emerald-700' : 'text-rose-700'}>
                          {isPassed ? `উত্তীর্ণ (GPA ${gpaRes.totalGPA.toFixed(2)})` : `অনুত্তীর্ণ (${gpaRes.overallGrade})`}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-600">
                        {isPassed
                          ? 'অভিনন্দন! আপনার সার্বিক ফলাফল চমৎকার। এই ধারাবাহিকতা ধরে রাখতে নিয়মিত পড়াশোনা অব্যাহত রাখুন।'
                          : 'মনোযোগ দিয়ে দুর্বল বিষয়গুলোতে বিশেষ প্রস্তুতি ও শিক্ষক সহায়তার পরামর্শ দেওয়া হচ্ছে।'}
                      </p>
                    </div>
                  );
                })()}
              </div>
            </div>
          </div>
        </div>
        )}
        </div>
      )}

      {/* ===================================================================== */}
      {/* FEATURE 6: FEE JOMAR STATEMENT (অভিভাবক পোর্টালের জন্য)                */}
      {/* ===================================================================== */}
      {isGuardianView && activeSubTab === 'fees' && (
        <div className="space-y-6">
          {/* Fee Summary Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-center">
            <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs">
              <span className="text-xs text-slate-500 font-bold block">মোট নির্ধারিত ফি</span>
              <span className="text-2xl font-black text-slate-900 mt-1 block">
                {formatTaka(totalFeeBilled)}
              </span>
            </div>
            <div className="p-4 bg-white rounded-2xl border border-emerald-200 shadow-xs bg-emerald-50/30">
              <span className="text-xs text-emerald-700 font-bold block">মোট পরিশোধিত</span>
              <span className="text-2xl font-black text-emerald-700 mt-1 block">
                {formatTaka(totalFeePaid)}
              </span>
            </div>
            <div className="p-4 bg-white rounded-2xl border border-rose-200 shadow-xs bg-rose-50/30">
              <span className="text-xs text-rose-700 font-bold block">মোট বকেয়া</span>
              <span className="text-2xl font-black text-rose-700 mt-1 block">
                {formatTaka(totalFeeDue)}
              </span>
            </div>
          </div>

          {/* Section 1: বকেয়া ফি বিবরণী (Due Ledger) */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="p-4 border-b border-slate-100 flex flex-wrap items-center justify-between gap-3 bg-rose-50/40">
              <div>
                <h3 className="font-black text-slate-900 text-sm flex items-center gap-2">
                  <Wallet className="w-4 h-4 text-rose-600" />
                  <span>বকেয়া ফি বিবরণী (Due Ledger) - {student.nameBn || student.nameEn}</span>
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  কোন কোন ফি খাতে কত টাকা বকেয়া রয়েছে ও জমার শেষ তারিখ
                </p>
              </div>
              <div className="flex items-center space-x-2">
                <span className="px-2.5 py-1 rounded-full text-xs font-black bg-rose-100 text-rose-800">
                  {toBnNumber(studentDues.length)} টি বকেয়া
                </span>
                {totalFeeDue > 0 && (
                  <button
                    onClick={() => openPaymentModal('all')}
                    className="flex items-center space-x-1.5 px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-black shadow-xs transition-colors"
                  >
                    <CreditCard className="w-3.5 h-3.5" />
                    <span>সকল বকেয়া পরিশোধ ({formatTaka(totalFeeDue)})</span>
                  </button>
                )}
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-700 uppercase font-bold text-[10px] border-b border-slate-200">
                  <tr>
                    <th className="py-3 px-4">ফি এর খাত (Fee Title)</th>
                    <th className="py-3 px-4">সেশন / মাস</th>
                    <th className="py-3 px-4">জমার শেষ তারিখ</th>
                    <th className="py-3 px-4">বকেয়ার পরিমাণ</th>
                    <th className="py-3 px-4">স্ট্যাটাস</th>
                    <th className="py-3 px-4 text-right">অ্যাকশন</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-medium">
                  {studentDues.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="py-8 text-center text-emerald-700 font-bold">
                        🎉 আলহামদুলিল্লাহ! এই শিক্ষার্থীর কোনো বকেয়া ফি নেই।
                      </td>
                    </tr>
                  ) : (
                    studentDues.map((due) => (
                      <tr key={due.id} className="hover:bg-rose-50/30">
                        <td className="py-3 px-4 font-bold text-slate-900">{due.headName}</td>
                        <td className="py-3 px-4 text-slate-600">{due.month || '2026'}</td>
                        <td className="py-3 px-4 font-mono text-slate-600">{formatDate(due.dueDate || '2026-10-30')}</td>
                        <td className="py-3 px-4 font-black text-rose-700 text-sm">{formatTaka(due.amount)}</td>
                        <td className="py-3 px-4">
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-black border ${
                            due.isOverdue
                              ? 'bg-rose-100 text-rose-800 border-rose-300'
                              : 'bg-amber-100 text-amber-800 border-amber-300'
                          }`}>
                            {due.isOverdue ? 'মেয়াদোত্তীর্ণ' : 'বকেয়া'}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-right">
                          <button
                            onClick={() => openPaymentModal(due)}
                            className="px-3 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold shadow-2xs transition-colors"
                          >
                            জমা দিন
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>

            {studentDues.length > 0 && (
              <div className="p-4 bg-rose-50/60 border-t border-rose-100 flex items-center justify-between text-xs font-black">
                <span className="text-slate-700">সর্বমোট বকেয়া (GRAND TOTAL DUE):</span>
                <span className="text-base text-rose-700">{formatTaka(totalFeeDue)}</span>
              </div>
            )}
          </div>

          {/* Section 1.5: অনলাইন পেমেন্ট রিকোয়েস্ট ও অনুমোদন স্থিতি (Online Payment Requests & Status) */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="p-4 bg-gradient-to-r from-blue-50/90 to-indigo-50/70 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div className="flex items-center space-x-2.5">
                <div className="p-2 bg-indigo-600 text-white rounded-xl shadow-2xs">
                  <Smartphone className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-black text-slate-900 text-sm">
                    অনলাইন পেমেন্ট রিকোয়েস্ট ও অনুমোদন স্থিতি (bKash, Nagad & Rocket Requests)
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    বিকাশ, নগদ বা রকেট-এ পেমেন্ট রিকোয়েস্ট দেওয়ার পর স্কুল প্রশাসন ট্রানজেকশন যাচাই করে অনুমোদন দিলে বকেয়া বাদ যাবে এবং মানি রসিদ সক্রিয় হবে।
                  </p>
                </div>
              </div>
              <span className="px-2.5 py-1 rounded-full text-[11px] font-bold bg-white text-indigo-700 border border-indigo-200 shadow-2xs self-start sm:self-auto">
                মোট আবেদন: {toBnNumber(studentOnlineRequests.length)}টি
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-700 uppercase font-bold text-[10px] border-b border-slate-200">
                  <tr>
                    <th className="py-3 px-4">তারিখ</th>
                    <th className="py-3 px-4">রিকোয়েস্ট আইডি</th>
                    <th className="py-3 px-4">ফি এর বিবরণ</th>
                    <th className="py-3 px-4">মাধ্যম</th>
                    <th className="py-3 px-4">প্রেরক নম্বর</th>
                    <th className="py-3 px-4">ট্রানজেকশন আইডি (TrxID)</th>
                    <th className="py-3 px-4 text-right">টাকা</th>
                    <th className="py-3 px-4 text-center">অনুমোদন স্থিতি</th>
                    <th className="py-3 px-4 text-right">রসিদ / অ্যাকশন</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-medium">
                  {studentOnlineRequests.length === 0 ? (
                    <tr>
                      <td colSpan={9} className="py-6 text-center text-slate-400">
                        এখনও বিকাশ, নগদ বা রকেট-এ কোনো অনলাইন ফি জমার আবেদন করা হয়নি। বকেয়া ফি-এর পাশে 'জমা দিন' বাটনে ক্লিক করে বিকাশ/নগদ/রকেটে ফি জমা দিন।
                      </td>
                    </tr>
                  ) : (
                    studentOnlineRequests.map((req) => (
                      <tr key={req.id} className="hover:bg-slate-50">
                        <td className="py-3 px-4 font-mono text-slate-600">{formatDate(req.requestDate)}</td>
                        <td className="py-3 px-4 font-mono font-bold text-slate-800">{req.receiptNo}</td>
                        <td className="py-3 px-4 font-bold text-slate-900">{req.feeTitle}</td>
                        <td className="py-3 px-4">
                          <span
                            className={`px-2.5 py-0.5 rounded-full text-[10px] font-black ${
                              req.paymentMethod === 'bKash'
                                ? 'bg-pink-100 text-pink-700 border border-pink-200'
                                : req.paymentMethod === 'Rocket'
                                ? 'bg-purple-100 text-purple-700 border border-purple-200'
                                : 'bg-orange-100 text-orange-700 border border-orange-200'
                            }`}
                          >
                            {req.paymentMethod === 'bKash'
                              ? 'বিকাশ (bKash)'
                              : req.paymentMethod === 'Rocket'
                              ? 'রকেট (Rocket)'
                              : 'নগদ (Nagad)'}
                          </span>
                        </td>
                        <td className="py-3 px-4 font-mono text-slate-700">{req.senderPhone}</td>
                        <td className="py-3 px-4 font-mono font-bold text-blue-700 select-all">{req.transactionId}</td>
                        <td className="py-3 px-4 text-right font-black text-slate-900">{formatTaka(req.amount)}</td>
                        <td className="py-3 px-4 text-center">
                          {req.status === 'pending' && (
                            <div className="inline-flex flex-col items-center">
                              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-amber-100 text-amber-900 border border-amber-300">
                                🟡 অপেক্ষমাণ (Pending)
                              </span>
                              <span className="text-[9px] text-amber-700 mt-0.5">স্কুল কর্তৃপক্ষ যাচাই করছে</span>
                            </div>
                          )}
                          {req.status === 'approved' && (
                            <div className="inline-flex flex-col items-center">
                              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-emerald-100 text-emerald-800 border border-emerald-300">
                                🟢 অনুমোদিত (Approved)
                              </span>
                              {req.approvedAt && (
                                <span className="text-[9px] text-emerald-600 mt-0.5">{formatDate(req.approvedAt)}</span>
                              )}
                            </div>
                          )}
                          {req.status === 'rejected' && (
                            <div className="inline-flex flex-col items-center">
                              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-rose-100 text-rose-800 border border-rose-300">
                                🔴 বাতিল (Rejected)
                              </span>
                              {req.rejectedReason && (
                                <span className="text-[10px] text-rose-700 font-bold mt-0.5 max-w-xs text-center">
                                  কারণ: {req.rejectedReason}
                                </span>
                              )}
                            </div>
                          )}
                        </td>
                        <td className="py-3 px-4 text-right">
                          {req.status === 'approved' ? (
                            <button
                              onClick={() => {
                                setPaymentSuccessReceipt({
                                  receiptNo: req.receiptNo,
                                  amount: req.amount,
                                  feeTitle: req.feeTitle,
                                  date: req.approvedAt || req.requestDate,
                                  method: req.paymentMethod,
                                });
                              }}
                              className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold shadow-2xs"
                            >
                              রসিদ প্রিন্ট
                            </button>
                          ) : req.status === 'pending' ? (
                            <span className="text-[11px] text-amber-700 font-medium italic">অনুমোদনের অপেক্ষায়</span>
                          ) : (
                            <span className="text-[11px] text-rose-600 font-medium">প্রত্যাখ্যাত</span>
                          )}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Section 2: পরিশোধিত ফি বিবরণী ও রসিদ (Invoices & Receipts) */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="p-4 border-b border-slate-100 flex items-center justify-between">
              <h3 className="font-black text-slate-900 text-sm flex items-center gap-2">
                <FileText className="w-4 h-4 text-blue-600" />
                <span>ফি জমার বিবরণী ও রসিদ ({student.nameBn || student.nameEn})</span>
              </h3>
              <span className="text-xs font-bold text-slate-500">
                পরিশোধ সংখ্যা: {toBnNumber(unifiedPaidRecords.length)} টি
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-700 uppercase font-bold text-[10px] border-b border-slate-200">
                  <tr>
                    <th className="py-3 px-4">ইনভয়েস / রসিদ নং</th>
                    <th className="py-3 px-4">ফি এর বিবরণ / মাস</th>
                    <th className="py-3 px-4">তারিখ</th>
                    <th className="py-3 px-4">পরিশোধিত টাকা</th>
                    <th className="py-3 px-4">মাধ্যম</th>
                    <th className="py-3 px-4">স্ট্যাটাস</th>
                    <th className="py-3 px-4 text-right">রসিদ</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-medium">
                  {unifiedPaidRecords.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="py-8 text-center text-slate-400">
                        এখনও কোনো ফি জমা বা ইনভয়েস পাওয়া যায়নি।
                      </td>
                    </tr>
                  ) : (
                    unifiedPaidRecords.map((item) => (
                      <tr key={item.id} className="hover:bg-slate-50">
                        <td className="py-3 px-4 font-mono font-bold text-blue-700">
                          <div>{item.receiptNo}</div>
                          {item.invoiceNo && item.invoiceNo !== item.receiptNo && (
                            <div className="text-[10px] text-slate-400 font-normal">ইনভয়েস: {item.invoiceNo}</div>
                          )}
                        </td>
                        <td className="py-3 px-4 font-bold text-slate-900">{item.feeTitle}</td>
                        <td className="py-3 px-4 text-slate-600">{formatDate(item.date)}</td>
                        <td className="py-3 px-4 text-emerald-700 font-bold">{formatTaka(item.amount)}</td>
                        <td className="py-3 px-4 text-slate-600">{item.method}</td>
                        <td className="py-3 px-4">
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-emerald-100 text-emerald-800">
                            {item.status}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-right">
                          <button
                            onClick={() => {
                              setPaymentSuccessReceipt({
                                receiptNo: item.receiptNo,
                                amount: item.amount,
                                feeTitle: item.feeTitle,
                                date: item.date,
                                method: item.method,
                              });
                            }}
                            className="px-2.5 py-1 bg-blue-50 hover:bg-blue-100 text-blue-700 rounded-lg text-xs font-bold"
                          >
                            রসিদ
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* FEATURE 7: SCHOOL BLOG POSTS (READ-ONLY FOR STUDENT & GUARDIAN)       */}
      {/* ===================================================================== */}
      {activeSubTab === 'blogs' && (
        <div className="space-y-5">
          {/* Header Card */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <Newspaper className="w-5 h-5 text-indigo-600" />
                <h3 className="text-base sm:text-lg font-black text-slate-900">
                  {language === 'bn' ? 'স্কুল ব্লগ ও প্রকাশনা (School Blogs)' : 'School Blog & Publications'}
                </h3>
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-indigo-50 text-indigo-700 border border-indigo-200">
                  {language === 'bn'
                    ? `মোট ${toBnNumber(publishedBlogs.length)}টি ব্লগ`
                    : `${publishedBlogs.length} posts`}
                </span>
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-700 border border-slate-200 inline-flex items-center gap-1">
                  <Eye className="w-3 h-3 text-slate-500" />
                  <span>{language === 'bn' ? 'শুধুমাত্র পাঠযোগ্য' : 'Read-Only'}</span>
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-1">
                {language === 'bn'
                  ? 'বিদ্যালয়ের সুপার অ্যাডমিন কর্তৃক প্রকাশিত সকল শিক্ষামূলক, বিজ্ঞান, সহশিক্ষা ও অনুষ্ঠান বিষয়ক ব্লগ পোস্ট এখান থেকে পড়তে পারবেন।'
                  : 'Read all published school articles, science updates, and event stories shared by the School Super Admin.'}
              </p>
            </div>
          </div>

          {/* Search & Category Filter Bar */}
          <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
              <input
                type="text"
                placeholder={
                  language === 'bn'
                    ? 'ব্লগের শিরোনাম বা বিষয় দিয়ে খুঁজুন...'
                    : 'Search blogs by title or topic...'
                }
                value={blogSearchTerm}
                onChange={(e) => setBlogSearchTerm(e.target.value)}
                className="w-full pl-9 pr-3 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 bg-slate-50 focus:bg-white font-medium"
              />
            </div>

            <select
              value={blogCategoryFilter}
              onChange={(e) => setBlogCategoryFilter(e.target.value)}
              className="px-3 py-2 border border-slate-200 rounded-xl bg-white font-semibold text-slate-700 focus:ring-2 focus:ring-indigo-500"
            >
              <option value="all">{language === 'bn' ? 'সকল ক্যাটাগরি' : 'All Categories'}</option>
              {blogCategories.map((c) => (
                <option key={c.en} value={c.en}>
                  {language === 'bn' ? c.bn : c.en}
                </option>
              ))}
            </select>
          </div>

          {/* Published Blog Grid (Strictly Read-Only) */}
          {filteredBlogs.length === 0 ? (
            <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center text-slate-500">
              <Newspaper className="w-12 h-12 text-slate-300 mx-auto mb-3" />
              <p className="font-bold text-sm text-slate-700">
                {language === 'bn'
                  ? 'এখনও কোনো প্রকাশিত ব্লগ পোস্ট পাওয়া যায়নি।'
                  : 'No published blog posts found.'}
              </p>
              <p className="text-xs text-slate-400 mt-1">
                {language === 'bn'
                  ? 'স্কুল সুপার অ্যাডমিন কোনো ব্লগ পোস্ট প্রকাশ করলে তা এখানে স্বয়ংক্রিয়ভাবে প্রদর্শিত হবে।'
                  : 'Published articles from the School Super Admin will appear here automatically.'}
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {filteredBlogs.map((post) => (
                <div
                  key={post.id}
                  onClick={() => setReadingBlogPost(post)}
                  role="button"
                  tabIndex={0}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                      e.preventDefault();
                      setReadingBlogPost(post);
                    }
                  }}
                  className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs hover:shadow-md hover:border-indigo-300 transition-all flex flex-col justify-between cursor-pointer group"
                >
                  <div>
                    <div className="relative h-44 bg-slate-100 overflow-hidden">
                      <img
                        src={post.coverImage || '/assets/aistudio/school_hero.webp'}
                        alt={post.titleBn || post.titleEn}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                      <div className="absolute top-3 left-3 flex items-center space-x-1.5">
                        <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-white/95 text-blue-900 shadow-xs border border-slate-200">
                          {language === 'bn' ? post.categoryBn : post.category}
                        </span>
                        {post.featured && (
                          <span className="px-2 py-1 rounded-full text-[10px] font-bold bg-amber-400 text-amber-950 shadow-xs">
                            ★ {language === 'bn' ? 'ফিচার্ড' : 'Featured'}
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="p-4 space-y-2.5">
                      <div className="flex items-center space-x-3 text-[11px] text-slate-400">
                        <span className="flex items-center space-x-1">
                          <Calendar className="w-3 h-3" />
                          <span>{formatDate(post.publishedAt)}</span>
                        </span>
                        <span className="flex items-center space-x-1">
                          <User className="w-3 h-3" />
                          <span className="truncate max-w-[130px]">{post.authorName}</span>
                        </span>
                      </div>

                      <h4 className="font-bold text-slate-900 text-sm leading-snug line-clamp-2 group-hover:text-indigo-700">
                        {language === 'bn' ? post.titleBn || post.titleEn : post.titleEn || post.titleBn}
                      </h4>

                      <p className="text-xs text-slate-600 line-clamp-3 leading-relaxed">
                        {post.excerpt || post.content}
                      </p>
                    </div>
                  </div>

                  <div className="p-4 pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
                    <span className="inline-flex items-center space-x-1 text-indigo-600 font-bold group-hover:text-indigo-800">
                      <Eye className="w-3.5 h-3.5" />
                      <span>{language === 'bn' ? 'সম্পূর্ণ পড়ুন (Read)' : 'Read Full Article'}</span>
                    </span>
                    <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-indigo-600 group-hover:translate-x-0.5 transition-all" />
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Student Digital ID Card hidden from Student Portal per institutional policy */}

      {/* ===================================================================== */}
      {/* STUDENT SUBMISSION MODAL                                              */}
      {/* ===================================================================== */}
      {submittingHw && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-lg w-full p-6 text-xs text-slate-900 my-8">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h3 className="font-bold text-slate-900 text-base flex items-center gap-1.5">
                  <Upload className="w-4 h-4 text-blue-600" />
                  <span>বাড়ির কাজ জমা দিন</span>
                </h3>
                <p className="text-[11px] text-slate-500">
                  {submittingHw.title} ({submittingHw.subjectName})
                </p>
              </div>
              <button onClick={() => setSubmittingHw(null)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            {submissionMessage && (
              <div className="mt-3 p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 text-xs font-semibold flex items-center space-x-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>{submissionMessage}</span>
              </div>
            )}

            <form onSubmit={handleSubmitHomework} className="mt-4 space-y-4">
              <div>
                <label className="block font-bold text-slate-700 mb-1.5">
                  হস্তলিখিত খাতার ছবি তুলুন (ক্যামেরা):
                </label>
                <div className="flex items-center gap-2">
                  <label className="flex-1 flex items-center justify-center space-x-2 px-4 py-3 bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-700 hover:to-blue-700 text-white rounded-xl font-bold cursor-pointer shadow-md transition-all active:scale-95">
                    <Camera className="w-5 h-5 text-amber-300" />
                    <span className="text-sm">ক্যামেরা দিয়ে ছবি তুলুন (Take Photo with Camera)</span>
                    <input
                      type="file"
                      accept="image/*"
                      capture="environment"
                      onChange={handleImageUpload}
                      className="hidden"
                    />
                  </label>
                </div>

                {submissionImages.length > 0 && (
                  <div className="grid grid-cols-3 sm:grid-cols-4 gap-2 mt-3">
                    {submissionImages.map((img, idx) => (
                      <div key={idx} className="relative rounded-lg overflow-hidden border border-slate-200 aspect-square group shadow-xs">
                        <img src={img} alt={`Page ${idx + 1}`} className="w-full h-full object-cover" />
                        <button
                          type="button"
                          onClick={() => setSubmissionImages((prev) => prev.filter((_, i) => i !== idx))}
                          className="absolute top-1 right-1 p-1 bg-rose-600 hover:bg-rose-700 text-white rounded-full shadow-md"
                          title="ছবি মুছুন"
                        >
                          <X className="w-3 h-3" />
                        </button>
                        <span className="absolute bottom-1 left-1 px-1.5 py-0.5 rounded bg-black/60 text-white text-[9px] font-bold">
                          পৃষ্ঠা {toBnNumber(idx + 1)}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  লিখিত উত্তর (ঐচ্ছিক):
                </label>
                <textarea
                  rows={3}
                  value={submissionText}
                  onChange={(e) => setSubmissionText(e.target.value)}
                  placeholder="আপনার লিখিত সমাধান বা কোনো মন্তব্য এখানে লিখুন..."
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl"
                />
              </div>

              <div className="pt-2 flex items-center justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => setSubmittingHw(null)}
                  className="px-4 py-2 border border-slate-200 rounded-xl text-slate-600 hover:bg-slate-50 font-semibold"
                >
                  {submissionMessage ? 'বন্ধ করুন' : 'বাতিল'}
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting || isEvaluatingAi}
                  className="px-5 py-2 bg-blue-600 hover:bg-blue-700 disabled:opacity-60 text-white rounded-xl font-bold shadow-xs transition-colors"
                >
                  {isSubmitting
                    ? 'জমা হচ্ছে...'
                    : isEvaluatingAi
                    ? 'এআই মূল্যায়ন চলছে...'
                    : 'জমা সম্পন্ন করুন'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* ONLINE FEE PAYMENT MODAL (STRICTLY bKash & Nagad ONLY - NO CASH)     */}
      {/* ===================================================================== */}
      {payingDue && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-md w-full p-6 text-xs text-slate-900 my-8">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h3 className="font-bold text-slate-900 text-base flex items-center gap-1.5">
                  <Smartphone className="w-5 h-5 text-indigo-600" />
                  <span>অনলাইন ফি পরিশোধ (বিকাশ, নগদ ও রকেট)</span>
                </h3>
                <p className="text-[11px] text-slate-500">
                  {payingDue === 'all' ? 'সকল বকেয়া ফি পরিশোধ' : payingDue.headName}
                </p>
              </div>
              <button onClick={() => setPayingDue(null)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleProcessPayment} className="mt-4 space-y-4">
              {paymentError && (
                <div className="p-2.5 bg-rose-50 border border-rose-200 rounded-xl text-rose-700 text-xs font-bold">
                  {paymentError}
                </div>
              )}
              <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl flex items-center justify-between">
                <div>
                  <span className="text-[10px] text-rose-700 font-bold block uppercase">পরিশোধযোগ্য বকেয়া টাকা</span>
                  <span className="text-xl font-black text-rose-800">
                    {formatTaka(payingDue === 'all' ? totalFeeDue : payingDue.amount)}
                  </span>
                </div>
                <span className="px-2.5 py-1 rounded-full text-[10px] font-black bg-rose-200 text-rose-900">
                  {payingDue === 'all' ? `${toBnNumber(studentDues.length)}টি ফি খাত` : 'একক ফি'}
                </span>
              </div>

              {/* MFS Method Selection - bKash, Nagad & Rocket */}
              <div>
                <label className="block font-bold text-slate-700 mb-1.5">
                  অনলাইন মাধ্যম নির্বাচন করুন (বিকাশ / নগদ / রকেট):
                </label>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setPaymentMethod('bKash')}
                    className={`p-2.5 rounded-xl border text-center font-black transition-all flex flex-col items-center justify-center gap-1 ${
                      paymentMethod === 'bKash'
                        ? 'border-pink-500 bg-pink-50 text-pink-700 ring-2 ring-pink-400 shadow-xs'
                        : 'border-slate-200 hover:bg-slate-50 text-slate-600'
                    }`}
                  >
                    <span className="w-2.5 h-2.5 rounded-full bg-pink-600 inline-block"></span>
                    <span className="text-xs">বিকাশ (bKash)</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setPaymentMethod('Nagad')}
                    className={`p-2.5 rounded-xl border text-center font-black transition-all flex flex-col items-center justify-center gap-1 ${
                      paymentMethod === 'Nagad'
                        ? 'border-orange-500 bg-orange-50 text-orange-700 ring-2 ring-orange-400 shadow-xs'
                        : 'border-slate-200 hover:bg-slate-50 text-slate-600'
                    }`}
                  >
                    <span className="w-2.5 h-2.5 rounded-full bg-orange-600 inline-block"></span>
                    <span className="text-xs">নগদ (Nagad)</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setPaymentMethod('Rocket')}
                    className={`p-2.5 rounded-xl border text-center font-black transition-all flex flex-col items-center justify-center gap-1 ${
                      paymentMethod === 'Rocket'
                        ? 'border-purple-600 bg-purple-50 text-purple-800 ring-2 ring-purple-400 shadow-xs'
                        : 'border-slate-200 hover:bg-slate-50 text-slate-600'
                    }`}
                  >
                    <span className="w-2.5 h-2.5 rounded-full bg-purple-600 inline-block"></span>
                    <span className="text-xs">রকেট (Rocket)</span>
                  </button>
                </div>
              </div>

              {/* School MFS Number and Instructions Card */}
              <div className={`p-3 rounded-xl border space-y-1.5 ${
                paymentMethod === 'bKash'
                  ? 'bg-pink-50/70 border-pink-200'
                  : paymentMethod === 'Rocket'
                  ? 'bg-purple-50/70 border-purple-200'
                  : 'bg-orange-50/70 border-orange-200'
              }`}>
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold text-slate-700">
                    স্কুলের নির্ধারিত {paymentMethod === 'bKash' ? 'বিকাশ' : paymentMethod === 'Rocket' ? 'রকেট' : 'নগদ'} নম্বর:
                  </span>
                  <span className="px-2 py-0.5 rounded text-[9px] font-black uppercase bg-white border border-slate-200 text-slate-800">
                    {paymentMethod === 'bKash'
                      ? mfsSettings.bkashType
                      : paymentMethod === 'Rocket'
                      ? mfsSettings.rocketType || 'Personal'
                      : mfsSettings.nagadType}
                  </span>
                </div>
                <div className="text-base font-black font-mono tracking-wider select-all text-slate-900">
                  {paymentMethod === 'bKash'
                    ? mfsSettings.bkashNumber
                    : paymentMethod === 'Rocket'
                    ? mfsSettings.rocketNumber || '01811234567'
                    : mfsSettings.nagadNumber}
                </div>
                <p className="text-[10px] text-slate-600 leading-relaxed pt-1 border-t border-slate-200/60">
                  {mfsSettings.instructionsBn ||
                    'উপরের নম্বরে টাকা পাঠানোর পর প্রেরক নম্বর ও ট্রানজেকশন আইডি (TrxID) নিচে লিখে সাবমিট করুন।'}
                </p>
              </div>

              {/* Sender Phone Number */}
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  যে নম্বর থেকে টাকা পাঠিয়েছেন (প্রেরক মোবাইল নম্বর) *:
                </label>
                <input
                  type="text"
                  required
                  value={paymentPhone}
                  onChange={(e) => setPaymentPhone(e.target.value)}
                  placeholder="01XXXXXXXXX"
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl font-mono text-sm focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              {/* TrxID */}
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  ট্রানজেকশন আইডি (TrxID) *:
                </label>
                <input
                  type="text"
                  required
                  value={paymentTrxId}
                  onChange={(e) => setPaymentTrxId(e.target.value)}
                  placeholder="যেমন: BK9281745 / 7G8X2K"
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl font-mono uppercase font-bold text-slate-900 focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div className="p-2.5 bg-amber-50 border border-amber-200 rounded-xl text-[11px] text-amber-900 flex items-start space-x-2">
                <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                <span>
                  পেমেন্ট জমা দেওয়ার সাথে সাথে এটি <strong>অপেক্ষমাণ (Pending)</strong> থাকবে। স্কুল প্রশাসন TrxID যাচাই করে অনুমোদন (Approve) দিলে আপনার বকেয়া বাদ যাবে এবং মানি রিসিট প্রিন্ট করতে পারবেন।
                </span>
              </div>

              <div className="pt-2 flex items-center justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => setPayingDue(null)}
                  className="px-4 py-2 border border-slate-200 rounded-xl text-slate-600 hover:bg-slate-50 font-semibold"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  disabled={isProcessingPayment}
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold shadow-xs transition-colors flex items-center space-x-1.5"
                >
                  <Smartphone className="w-4 h-4" />
                  <span>{isProcessingPayment ? 'আবেদন পাঠানো হচ্ছে...' : 'পেমেন্ট রিকোয়েস্ট পাঠান'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* PAYMENT REQUEST SUBMITTED SUCCESS MODAL                               */}
      {/* ===================================================================== */}
      {paymentRequestSubmitted && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-md w-full p-6 text-xs text-slate-900 my-8 animate-in zoom-in-95">
            <div className="text-center pb-4 border-b border-slate-100">
              <div className="w-12 h-12 bg-amber-100 text-amber-600 rounded-full flex items-center justify-center mx-auto mb-2 shadow-xs">
                <Clock className="w-6 h-6 stroke-[2.5]" />
              </div>
              <h3 className="font-black text-slate-900 text-base">পেমেন্ট রিকোয়েস্ট সফলভাবে জমা হয়েছে!</h3>
              <p className="text-[11px] text-slate-500">অনুমোদনের জন্য অপেক্ষমাণ (Pending Approval)</p>
            </div>

            <div className="mt-4 p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2.5 font-medium">
              <div className="flex items-center justify-between">
                <span className="text-slate-500">রিকোয়েস্ট আইডি:</span>
                <span className="font-mono font-bold text-blue-700">{paymentRequestSubmitted.receiptNo}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-500">ফি এর বিবরণ:</span>
                <span className="font-bold text-slate-900">{paymentRequestSubmitted.feeTitle}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-500">পেমেন্ট মাধ্যম:</span>
                <span className="font-bold text-slate-900">{paymentRequestSubmitted.method}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-500">প্রেরক নম্বর:</span>
                <span className="font-mono text-slate-800">{paymentRequestSubmitted.senderPhone}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-500">ট্রানজেকশন আইডি:</span>
                <span className="font-mono font-bold text-blue-700 select-all">{paymentRequestSubmitted.trxId}</span>
              </div>
              <div className="pt-2 border-t border-slate-200 flex items-center justify-between text-sm font-black">
                <span className="text-slate-800">আবেদনের পরিমাণ:</span>
                <span className="text-emerald-700 text-base">{formatTaka(paymentRequestSubmitted.amount)}</span>
              </div>
            </div>

            <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-xl text-blue-900 text-[11px] leading-relaxed">
              ℹ️ স্কুল কর্তৃপক্ষ তথ্য যাচাই করে অনুমোদন (Approve) দিলে আপনার বকেয়া সমন্বয় হবে এবং মানি রিসিট প্রস্তুত হবে। আপনি এই ড্যাশবোর্ডের "অনলাইন পেমেন্ট রিকোয়েস্ট ও অনুমোদন স্থিতি" টেবিলে এর অগ্রগতি দেখতে পারবেন।
            </div>

            <div className="mt-5 flex items-center justify-end">
              <button
                type="button"
                onClick={() => setPaymentRequestSubmitted(null)}
                className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold shadow-xs transition-colors"
              >
                ঠিক আছে (বন্ধ করুন)
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* PAYMENT SUCCESS RECEIPT MODAL                                         */}
      {/* ===================================================================== */}
      {paymentSuccessReceipt && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-md w-full p-6 text-xs text-slate-900 my-8">
            <div className="text-center pb-4 border-b border-slate-100">
              <div className="w-12 h-12 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-2 shadow-xs">
                <Check className="w-6 h-6 stroke-[3]" />
              </div>
              <h3 className="font-black text-slate-900 text-base">ফি পরিশোধ সফল হয়েছে!</h3>
              <p className="text-[11px] text-slate-500">ডিজিটাল মানি রিসিট ও ভাউচার</p>
            </div>

            <div className="mt-4 p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2.5 font-medium">
              <div className="flex items-center justify-between">
                <span className="text-slate-500">রসিদ নম্বর:</span>
                <span className="font-mono font-bold text-blue-700">{paymentSuccessReceipt.receiptNo}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-500">শিক্ষার্থী:</span>
                <span className="font-bold text-slate-900">{student.nameBn || student.nameEn} ({student.studentId})</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-500">শ্রেণি ও রোল:</span>
                <span className="font-bold text-slate-900">{student.className} (রোল: {student.roll})</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-500">ফি এর বিবরণ:</span>
                <span className="font-bold text-slate-900">{paymentSuccessReceipt.feeTitle}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-500">পেমেন্ট মাধ্যম:</span>
                <span className="font-bold text-slate-900">{paymentSuccessReceipt.method}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-500">তারিখ:</span>
                <span className="font-mono text-slate-700">{formatDate(paymentSuccessReceipt.date)}</span>
              </div>
              <div className="pt-2 border-t border-slate-200 flex items-center justify-between text-sm font-black">
                <span className="text-slate-800">পরিশোধিত টাকা:</span>
                <span className="text-emerald-700 text-base">{formatTaka(paymentSuccessReceipt.amount)}</span>
              </div>
            </div>

            <div className="mt-5 flex items-center justify-end space-x-2">
              <button
                type="button"
                onClick={() => setPaymentSuccessReceipt(null)}
                className="px-4 py-2 border border-slate-200 rounded-xl text-slate-600 hover:bg-slate-50 font-semibold"
              >
                বন্ধ করুন
              </button>
              <button
                type="button"
                onClick={() => window.print()}
                className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold flex items-center space-x-1.5 shadow-xs"
              >
                <Printer className="w-4 h-4" />
                <span>রসিদ প্রিন্ট করুন</span>
              </button>
            </div>
          </div>
        </div>
      )}
      {/* ===================================================================== */}
      {/* READ-ONLY BLOG POST READER MODAL (STUDENT & GUARDIAN)                 */}
      {/* ===================================================================== */}
      {readingBlogPost && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-2xl w-full p-6 text-xs text-slate-900 my-8 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center space-x-2">
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-blue-100 text-blue-800">
                  {language === 'bn' ? readingBlogPost.categoryBn : readingBlogPost.category}
                </span>
                {readingBlogPost.featured && (
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-900 border border-amber-200">
                    ★ {language === 'bn' ? 'ফিচার্ড' : 'Featured'}
                  </span>
                )}
              </div>
              <button
                type="button"
                onClick={() => setReadingBlogPost(null)}
                className="text-slate-400 hover:text-slate-600 p-1 rounded-lg hover:bg-slate-100"
                aria-label="Close"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {readingBlogPost.coverImage && (
              <img
                src={readingBlogPost.coverImage}
                alt={readingBlogPost.titleBn || readingBlogPost.titleEn}
                className="w-full h-56 sm:h-64 object-cover rounded-xl mt-4 shadow-xs"
              />
            )}

            <h2 className="text-lg sm:text-xl font-black text-slate-900 mt-4 leading-snug">
              {readingBlogPost.titleBn || readingBlogPost.titleEn}
            </h2>
            {readingBlogPost.titleEn &&
              readingBlogPost.titleBn &&
              readingBlogPost.titleEn.trim() !== readingBlogPost.titleBn.trim() && (
                <p className="text-xs font-semibold text-slate-500 mt-1">{readingBlogPost.titleEn}</p>
              )}

            <div className="flex flex-wrap items-center gap-3 text-[11px] text-slate-500 mt-2.5 pb-3 border-b border-slate-100">
              <span className="flex items-center space-x-1">
                <Calendar className="w-3.5 h-3.5 text-slate-400" />
                <span>
                  {language === 'bn' ? 'প্রকাশনা:' : 'Published:'} {formatDate(readingBlogPost.publishedAt)}
                </span>
              </span>
              <span>•</span>
              <span className="flex items-center space-x-1">
                <User className="w-3.5 h-3.5 text-slate-400" />
                <span>
                  {language === 'bn' ? 'লেখক:' : 'Author:'} {readingBlogPost.authorName} ({readingBlogPost.authorRole})
                </span>
              </span>
            </div>

            <div className="text-xs sm:text-sm text-slate-700 whitespace-pre-line leading-relaxed mt-4 bg-slate-50 p-4 rounded-xl border border-slate-100">
              {readingBlogPost.content}
            </div>

            <div className="mt-5 flex justify-end">
              <button
                type="button"
                onClick={() => setReadingBlogPost(null)}
                className="px-5 py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-xl font-bold transition-colors"
              >
                {language === 'bn' ? 'বন্ধ করুন (Close)' : 'Close'}
              </button>
            </div>
          </div>
        </div>
      )}

      <AccountCredentialsModal
        isOpen={showStudentCredsModal}
        initialTab="my_account"
        onClose={() => setShowStudentCredsModal(false)}
      />
    </div>
  );
};
